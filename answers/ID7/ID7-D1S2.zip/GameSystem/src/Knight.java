
public interface Knight {

}
