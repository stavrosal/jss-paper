
public interface Archer {

}
