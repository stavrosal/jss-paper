
public class MMOKnight implements Knight {

	@Override
	public void printAbility() {
		// TODO Auto-generated method stub
		System.out.println("");
	}

}
