
public class MMOGameFactory implements GameFactory{

	@Override
	public Archer createArcher() {
		// TODO Auto-generated method stub
		return new MMOArcher();
	}

	@Override
	public Knight createKnight() {
		// TODO Auto-generated method stub
		return new MMOKnight();
	}

}
