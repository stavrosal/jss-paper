
public interface GameFactory {

}
