
public class MMOArcher {

}
