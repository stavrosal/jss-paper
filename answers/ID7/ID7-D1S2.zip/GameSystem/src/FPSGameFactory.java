
public class FPSGameFactory implements GameFactory {

}
