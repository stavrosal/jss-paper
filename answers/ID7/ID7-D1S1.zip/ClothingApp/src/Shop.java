
import java.util.ArrayList;
import java.util.List;

public class Shop {
    private ClothesFactory factory;
    private List<Clothes> inventory;

    public Shop(ClothesFactory factory) {
        this.factory = factory;
        this.inventory = new ArrayList<>();
    }

    public void stockShop() {
        inventory.add(factory.createShirt());
        inventory.add(factory.createPants());
    }

    public void showInventory() {
        for (Clothes c : inventory) {
            c.printInfo();
        }
    }
}