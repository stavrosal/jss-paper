
public class VintagePants extends Pants {
    public void printInfo() {
        System.out.println("A vintage pair of pants");
    }
}