
public class ModernClothesFactory implements ClothesFactory {
    public Shirt createShirt() {
        return new ModernShirt();
    }

    public Pants createPants() {
        return new ModernPants();
    }
}