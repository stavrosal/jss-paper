
public abstract class Pants extends Clothes {}
