public class ModernShirt extends Shirt {
    public void printInfo() {
        System.out.println("A modern shirt");
    }
}