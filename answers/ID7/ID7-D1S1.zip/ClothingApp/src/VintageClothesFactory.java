
public class VintageClothesFactory implements ClothesFactory {
    public Shirt createShirt() {
        return new VintageShirt();
    }

    public Pants createPants() {
        return new VintagePants();
    }
}
