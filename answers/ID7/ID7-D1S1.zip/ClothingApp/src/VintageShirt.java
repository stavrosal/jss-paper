
public class VintageShirt extends Shirt {
    public void printInfo() {
        System.out.println("A vintage shirt");
    }
}
