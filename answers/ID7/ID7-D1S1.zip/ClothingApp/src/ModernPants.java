
public class ModernPants extends Pants {
    public void printInfo() {
        System.out.println("A modern pair of pants");
    }
}