
public class Main {
    public static void main(String[] args) {
        Shop vintageShop = new Shop(new VintageClothesFactory());
        vintageShop.stockShop();
        vintageShop.showInventory();

        System.out.println("----");

        Shop modernShop = new Shop(new ModernClothesFactory());
        modernShop.stockShop();
        modernShop.showInventory();
    }
}
