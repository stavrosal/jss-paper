
public abstract class Clothes {
    public abstract void printInfo();
}