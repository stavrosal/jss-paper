
public abstract class Shirt extends Clothes {}
