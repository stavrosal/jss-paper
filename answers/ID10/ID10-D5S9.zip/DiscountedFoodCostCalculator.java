
import java.util.List;

public class DiscountedFoodCostCalculator implements FoodCostCalculator {
    public double calculate(List<Person> people) {
        int vegans = 0;
        for (Person p : people) {
            if (p.isVegan()) vegans++;
        }
        int nonVegans = people.size() - vegans;
        return nonVegans * 2.0 + vegans * 2.5;
    }
}
