
import java.util.List;

public class StandardFoodCostCalculator implements FoodCostCalculator {
    public double calculate(List<Person> people) {
        int vegans = 0;
        for (Person p : people) {
            if (p.isVegan()) vegans++;
        }
        int nonVegans = people.size() - vegans;
        return nonVegans * 3.0 + vegans * 3.5;
    }
}
