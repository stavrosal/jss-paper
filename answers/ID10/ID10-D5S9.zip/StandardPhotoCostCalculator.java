
import java.util.List;

public class StandardPhotoCostCalculator implements PhotoCostCalculator {
    public double calculate(List<Person> people) {
        int count = people.size();
        return count <= 600 ? count * 1.0 : count * 0.75;
    }
}
