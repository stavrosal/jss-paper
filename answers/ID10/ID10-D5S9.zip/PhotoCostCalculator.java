
import java.util.List;

public interface PhotoCostCalculator {
    double calculate(List<Person> people);
}
