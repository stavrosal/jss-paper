
import java.util.List;

public interface FoodCostCalculator {
    double calculate(List<Person> people);
}
