
public class Person {
    private boolean vegan;

    public Person(boolean vegan) {
        this.vegan = vegan;
    }

    public boolean isVegan() {
        return vegan;
    }
}
