
import java.util.List;

public class Wedding {
    private String venue;
    private List<Person> people;
    private FoodCostCalculator foodCalculator;
    private PhotoCostCalculator photoCalculator;

    public Wedding(String venue, List<Person> people, FoodCostCalculator foodCalculator, PhotoCostCalculator photoCalculator) {
        this.venue = venue;
        this.people = people;
        this.foodCalculator = foodCalculator;
        this.photoCalculator = photoCalculator;
    }

    public double calculateFoodCost() {
        return foodCalculator.calculate(people);
    }

    public double calculatePhotoCost() {
        return photoCalculator.calculate(people);
    }
}
