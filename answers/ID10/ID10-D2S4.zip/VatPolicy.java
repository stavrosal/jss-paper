public interface VatPolicy {
    double calculateVat(double baseCost);
}