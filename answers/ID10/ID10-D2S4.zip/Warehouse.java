public abstract class Warehouse {
    protected VatPolicy vatPolicy;

    public Warehouse(VatPolicy vatPolicy) {
        this.vatPolicy = vatPolicy;
    }

    public double calculateFinalCost(double baseCost) {
        return baseCost + vatPolicy.calculateVat(baseCost);
    }

    public abstract String getType();
}