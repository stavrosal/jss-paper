public class Main {
    public static void main(String[] args) {
        Warehouse warehouse1 = WarehouseFactory.createWarehouse("local");
        Warehouse warehouse2 = WarehouseFactory.createWarehouse("central");

        double baseCost = 1000.0;

        System.out.println(warehouse1.getType() + " cost: " + warehouse1.calculateFinalCost(baseCost));
        System.out.println(warehouse2.getType() + " cost: " + warehouse2.calculateFinalCost(baseCost));
    }
}