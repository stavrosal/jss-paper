public class CentralWarehouse extends Warehouse {
    public CentralWarehouse() {
        super(new NormalVatPolicy());
    }

    @Override
    public String getType() {
        return "Central";
    }
}