public class WarehouseFactory {
    public static Warehouse createWarehouse(String type) {
        switch (type.toLowerCase()) {
            case "local":
                return new LocalWarehouse();
            case "central":
                return new CentralWarehouse();
            default:
                throw new IllegalArgumentException("Unknown warehouse type");
        }
    }
}