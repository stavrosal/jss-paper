public class ExtraVatPolicy implements VatPolicy {
    @Override
    public double calculateVat(double baseCost) {
        return baseCost * 0.24;
    }
}