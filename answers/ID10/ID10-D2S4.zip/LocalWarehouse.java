public class LocalWarehouse extends Warehouse {
    public LocalWarehouse() {
        super(new ReducedVatPolicy());
    }

    @Override
    public String getType() {
        return "Local";
    }
}