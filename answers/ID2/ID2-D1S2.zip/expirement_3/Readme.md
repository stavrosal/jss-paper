
## Overview

This project implements an object-oriented system in Java for a clothing retail business. The system models a shop that specializes in a single clothing style (e.g., "Vintage" or "Modern") and sells different types of clothing items like shirts and pants.

The core focus is on demonstrating OOP principles such as abstraction, inheritance, polymorphism, and encapsulation, along with proper error handling for business rule violations.

## Features

*   **Style Specialization:** Shops are specialized to sell items of only one style (e.g., a "Modern" shop only sells "Modern" items).
*   **Clothing Item Hierarchy:**
    *   An abstract `ClothingItem` base class.
    *   Concrete `Shirt` and `Pants` subclasses.
*   **Style System:**
    *   A `Style` interface.
    *   `VintageStyle` and `ModernStyle` implementations.
*   **Inventory Management:**
    *   Shops maintain an inventory of clothing items.
    *   Items can be added to and removed from the inventory.
*   **Business Rule Enforcement:**
    *   Prevents adding items of an incompatible style to a shop.
*   **Custom Error Handling:**
    *   Uses a custom `StyleMismatchException` for style incompatibility issues.
*   **Demonstration Application:** A `ClothingShopApp` class showcases the system's functionality.

## Project Structure

The project follows a standard plain Java project structure:

```
ClothingShopProject/
├── out/                  <-- Compiled .class files will be placed here
├── src/
│   └── main/
│       └── java/
│           └── com/
│               └── clothingshop/
│                   ├── app/          # Main application/demonstration class
│                   │   └── ClothingShopApp.java
│                   ├── core/         # Core business logic (Shop)
│                   │   └── Shop.java
│                   ├── exceptions/   # Custom exception classes
│                   │   └── StyleMismatchException.java
│                   └── model/        # Data model classes
│                       ├── items/    # Clothing item classes
│                       │   ├── ClothingItem.java
│                       │   ├── Pants.java
│                       │   └── Shirt.java
│                       └── styles/   # Style-related classes
│                           ├── ModernStyle.java
│                           ├── Style.java
│                           └── VintageStyle.java
└── README.md             <-- This file
```

## Requirements

*   Java Development Kit (JDK) version 8 or higher (JDK 11 or 17 recommended).

## Setup and Compilation

1.  **Clone or Download the Project:**
    Obtain the project files and place them in a directory (e.g., `ClothingShopProject`).

2.  **Verify JDK Installation:**
    Open a terminal or command prompt and ensure `javac` (Java compiler) and `java` (Java runtime) are accessible:
    ```bash
    java -version
    javac -version
    ```
    If not, install a JDK and configure your system's PATH environment variable.

3.  **Compile the Source Code:**
    Navigate to the root directory of the project (e.g., `ClothingShopProject`) in your terminal.
    Run the following command to compile all Java source files and place the compiled `.class` files into the `out` directory:

    *   **Using PowerShell:**
        ```powershell
        $javaFiles = Get-ChildItem -Path src/main/java -Recurse -Filter *.java | ForEach-Object { $_.FullName }
        javac -d out $javaFiles
        ```
    *   **Using Bash (Linux/macOS/Git Bash on Windows):**
        ```bash
        find src/main/java -name "*.java" > sources.txt
        javac -d out @sources.txt
        rm sources.txt
        ```
    *   **Alternatively, listing all packages (simpler for this project size):**
        ```bash
        javac -d out src/main/java/com/clothingshop/model/styles/*.java src/main/java/com/clothingshop/model/items/*.java src/main/java/com/clothingshop/exceptions/*.java src/main/java/com/clothingshop/core/*.java src/main/java/com/clothingshop/app/*.java
        ```

    After successful compilation, the `out` directory will be created (if it doesn't exist) and populated with the compiled class files, maintaining the package structure.

## Running the Demonstration

Once the project is compiled, you can run the demonstration application:

1.  Navigate to the root directory of the project (e.g., `ClothingShopProject`) in your terminal.
2.  Execute the following command:
    ```bash
    java -cp out com.clothingshop.app.ClothingShopApp
    ```
    *   `-cp out`: Sets the classpath to the `out` directory, where the JVM will look for the compiled classes.
    *   `com.clothingshop.app.ClothingShopApp`: The fully qualified name of the main class to execute.

The application will print output to the console, demonstrating various scenarios such as creating shops, adding compatible and incompatible items, displaying inventory, and removing items.

## Code Overview

### Core Components:

*   **`Style` (interface):** Defines the contract for clothing styles (`getName()`).
    *   Implementations: `ModernStyle`, `VintageStyle`.
*   **`ClothingItem` (abstract class):** Base class for all clothing.
    *   Properties: `size`, `color`, `price`, `style`.
    *   Abstract method: `printInfo()`.
    *   Concrete subclasses: `Shirt`, `Pants` (provide `printInfo()` implementation).
*   **`StyleMismatchException` (custom exception):** Thrown when attempting to add an item of an incompatible style to a shop.
*   **`Shop` (class):**
    *   Manages an inventory of `ClothingItem`s.
    *   Specializes in a single `Style`.
    *   Methods: `addItem()`, `removeItem()`, `displayInventory()`.
*   **`ClothingShopApp` (class):** Contains the `main` method to run the demonstration.

## Development Environment

This project is designed to be simple to compile and run with a standard JDK and a text editor or IDE like Visual Studio Code (with Java extensions). No external build tools like Maven or Gradle are required for this basic version.
```
