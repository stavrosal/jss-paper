package com.clothingshop.model.items;

import com.clothingshop.model.styles.Style; // Required for the constructor parameter

/**
 * Represents a Shirt, a concrete type of {@link ClothingItem}.
 * It provides a specific implementation for printing shirt information.
 */
public class Shirt extends ClothingItem {

    /**
     * Constructs a new Shirt item.
     *
     * @param size The size of the shirt.
     * @param color The color of the shirt.
     * @param price The price of the shirt.
     * @param style The {@link Style} of the shirt (e.g., Vintage, Modern).
     */
    public Shirt(String size, String color, double price, Style style) {
        super(size, color, price, style); // Call the constructor of the superclass (ClothingItem)
    }

    /**
     * Prints information about the shirt in the format: "A [Style Name] Shirt".
     * Example: "A Vintage Shirt".
     */
    @Override
    public void printInfo() {
        // this.style is inherited from ClothingItem and accessible
        // Or, using the getter: getStyle().getName()
        System.out.println("A " + style.getName() + " Shirt");
    }
}