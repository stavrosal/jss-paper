package com.clothingshop.model.styles;

/**
 * Defines the contract for all clothing styles within the system.
 * Each style must be able to provide its name.
 * This interface allows for treating different style objects polymorphically.
 */
public interface Style {

    /**
     * Retrieves the name of the style.
     * For example, "Vintage", "Modern".
     *
     * @return A String representing the name of the style.
     */
    String getName();
}