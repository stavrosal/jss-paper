package com.clothingshop.model.items;

import com.clothingshop.model.styles.Style; // Import the Style interface

/**
 * Abstract base class representing a generic clothing item.
 * It defines common properties like size, color, price, and style,
 * and an abstract method for printing item information.
 * Concrete clothing items (e.g., Shirt, Pants) should extend this class.
 */
public abstract class ClothingItem {

    protected String size;
    protected String color;
    protected double price;
    protected Style style; // Composition: ClothingItem HAS-A Style

    /**
     * Constructs a ClothingItem with specified attributes.
     *
     * @param size The size of the clothing item (e.g., "S", "M", "L", "32x30").
     *             Cannot be null or empty.
     * @param color The color of the clothing item (e.g., "Blue", "Black").
     *              Cannot be null or empty.
     * @param price The price of the clothing item. Must be non-negative.
     * @param style The style of the clothing item (e.g., Vintage, Modern).
     *              Cannot be null.
     * @throws IllegalArgumentException if any of the validation rules for parameters are violated.
     */
    public ClothingItem(String size, String color, double price, Style style) {
        // Basic input validation
        if (size == null || size.trim().isEmpty()) {
            throw new IllegalArgumentException("Size cannot be null or empty.");
        }
        if (color == null || color.trim().isEmpty()) {
            throw new IllegalArgumentException("Color cannot be null or empty.");
        }
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative.");
        }
        if (style == null) {
            throw new IllegalArgumentException("Style cannot be null.");
        }

        this.size = size;
        this.color = color;
        this.price = price;
        this.style = style;
    }

    // --- Abstract Method ---
    /**
     * Prints detailed information about the clothing item.
     * The specific format is determined by concrete subclasses.
     * Example output: "A Vintage Shirt" or "A Modern Pants".
     */
    public abstract void printInfo();

    // --- Getters for properties ---
    /**
     * Gets the size of the clothing item.
     * @return The size.
     */
    public String getSize() {
        return size;
    }

    /**
     * Gets the color of the clothing item.
     * @return The color.
     */
    public String getColor() {
        return color;
    }

    /**
     * Gets the price of the clothing item.
     * @return The price.
     */
    public double getPrice() {
        return price;
    }

    /**
     * Gets the style of the clothing item.
     * @return The {@link Style} object associated with this item.
     */
    public Style getStyle() {
        return style;
    }

    // --- Optional: Setters (if items were mutable, not required by prompt) ---
    // For this project, we'll assume these properties are set at creation
    // and don't change. If they could change, you'd add setters:
    // public void setPrice(double price) { ... }
    // etc.

    // --- Optional: equals() and hashCode() ---
    // If we need to compare ClothingItem objects for equality based on their
    // properties (e.g., for checking if an item is already in inventory by value,
    // not just by reference), we would override equals() and hashCode().
    // For now, we'll rely on reference equality or simple property checks.
    // We might revisit this if removeItem() needs more sophisticated logic.

    // --- Optional: toString() ---
    /**
     * Provides a basic string representation of the ClothingItem.
     * Useful for debugging or simple logging.
     * Subclasses might want to override this for more specific information.
     * @return A string representation of the item's basic attributes.
     */
    @Override
    public String toString() {
        return "ClothingItem [size=" + size + ", color=" + color + ", price=" + price + ", style=" + style.getName() + "]";
    }
}