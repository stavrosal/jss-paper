# PowerShell Script to Create Clothing Shop Project Directory Structure
#
# Instructions:
# 1. Create a root folder for your project (e.g., "ClothingShopProject").
# 2. Open PowerShell.
# 3. Navigate into your root project folder (e.g., cd C:\path\to\your\ClothingShopProject).
# 4. Copy and paste this entire script into PowerShell and press Enter.

$baseSrcPath = "src"
$mainJavaPath = Join-Path $baseSrcPath "main\java\com\clothingshop"
$testJavaPath = Join-Path $baseSrcPath "test\java\com\clothingshop"

# Define main source directories
$mainDirs = @(
    (Join-Path $mainJavaPath "model\items"),
    (Join-Path $mainJavaPath "model\styles"),
    (Join-Path $mainJavaPath "core"),
    (Join-Path $mainJavaPath "exceptions"),
    (Join-Path $mainJavaPath "app")
)

# Define test source directories (mirroring main structure)
$testDirs = @(
    (Join-Path $testJavaPath "model\items"),
    (Join-Path $testJavaPath "model\styles"),
    (Join-Path $testJavaPath "core"),
    (Join-Path $testJavaPath "exceptions"),
    (Join-Path $testJavaPath "app") # If you plan to test the main app class directly
)

# Create an 'out' directory for compiled class files
$outDir = "out"

Write-Host "Creating project directory structure..."

# Create main source directories
foreach ($dir in $mainDirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "Created: $dir"
    } else {
        Write-Host "Exists: $dir"
    }
}

# Create test source directories
foreach ($dir in $testDirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "Created: $dir"
    } else {
        Write-Host "Exists: $dir"
    }
}

# Create output directory
if (-not (Test-Path $outDir)) {
    New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    Write-Host "Created: $outDir"
} else {
    Write-Host "Exists: $outDir"
}

Write-Host "Directory structure creation complete."
Write-Host "Project Root: $(Get-Location)"
Write-Host "Source files go into: $($mainDirs[0] | Split-Path -Parent | Split-Path -Parent | Split-Path -Parent)"
Write-Host "Test files go into: $($testDirs[0] | Split-Path -Parent | Split-Path -Parent | Split-Path -Parent)"
Write-Host "Compiled .class files will go into: $outDir (when using 'javac -d out ...')"