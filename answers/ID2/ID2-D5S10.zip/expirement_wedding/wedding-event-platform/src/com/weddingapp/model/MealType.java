package com.weddingapp.model;

/**
 * Represents the available types of meals an attendee can select.
 * Using an enum ensures type safety and clarity for meal selections.
 * 
 * Bob-Complete's Note: The business rules specify "Basic" and "Vegan" meals.
 * This enum directly models that requirement. If more meal types were introduced
 * with distinct pricing logic, this enum would be the first place to reflect that change,
 * and the costing services would adapt accordingly.
 */
public enum MealType {
    /**
     * Represents a basic meal option.
     */
    BASIC("Basic Meal"),

    /**
     * Represents a vegan meal option.
     */
    VEGAN("Vegan Meal");

    private final String displayName;

    /**
     * Private constructor for associating a display name with the enum constant.
     * @param displayName The human-readable name for the meal type.
     */
    MealType(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Gets the human-readable display name of the meal type.
     * @return The display name.
     */
    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName; // Provides a nice string representation
    }
}