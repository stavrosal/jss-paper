package com.weddingapp.main;

import com.weddingapp.model.MealType;
import com.weddingapp.model.Person;
import com.weddingapp.model.WeddingEvent;
import com.weddingapp.service.EventCostCalculator;
import com.weddingapp.service.EventCostCalculator.EventCostSummary; // Import the inner class

import java.util.ArrayList;
import java.util.List;
import java.util.Locale; // For consistent number formatting

/**
 * Main application class to demonstrate the Wedding Event Management Platform's
 * cost calculation capabilities.
 * 
 * Bob-Complete's Note: This class serves as a testbed and demonstration harness.
 * It creates various wedding event scenarios to showcase the functionality of the
 * data model and service layers, particularly the cost calculation logic for
 * catering and photography, including standard and volume discount pricing,
 * and edge cases like zero attendees or no photographer.
 */
public class Main {

    public static void main(String[] args) {
        // Set locale for consistent decimal formatting (e.g., using '.' as decimal separator)
        Locale.setDefault(Locale.US);

        System.out.println("Bob-Complete's Wedding Event Cost Calculator Demonstration");
        System.out.println("========================================================");

        EventCostCalculator costCalculator = new EventCostCalculator();

        // --- Scenario 1: Small Wedding (Standard Pricing) ---
        // Expected: Catering <= 500, Photography <= 600
        System.out.println("\n--- Scenario 1: Small Wedding (100 Attendees) ---");
        WeddingEvent smallWedding = new WeddingEvent("The Cozy Corner Chapel", true); // Photographer assigned
        addAttendeesWithPreferences(smallWedding, 100, 70, 30); // 70 Basic, 30 Vegan
        displayEventCosts(smallWedding, costCalculator);
        // Expected Catering: (70 * 3.00) + (30 * 3.50) = 210.00 + 105.00 = 315.00
        // Expected Photography: 100 * 1.00 = 100.00
        // Expected Total: 315.00 + 100.00 = 415.00

        // --- Scenario 2: Large Wedding (Volume Discount Pricing) ---
        // Expected: Catering > 500, Photography > 600
        System.out.println("\n--- Scenario 2: Large Wedding (650 Attendees) ---");
        WeddingEvent largeWedding = new WeddingEvent("Grand Ballroom Extravaganza", true); // Photographer assigned
        addAttendeesWithPreferences(largeWedding, 650, 400, 250); // 400 Basic, 250 Vegan
        displayEventCosts(largeWedding, costCalculator);
        // Expected Catering: (400 * 2.00) + (250 * 2.50) = 800.00 + 625.00 = 1425.00
        // Expected Photography: 650 * 0.75 = 487.50
        // Expected Total: 1425.00 + 487.50 = 1912.50

        // --- Scenario 3: Medium Wedding (Mixed Tiers - Catering Discount, Photography Standard) ---
        // Example: 550 attendees. Catering discount applies (>500), Photography standard rate applies (<=600)
        System.out.println("\n--- Scenario 3: Medium Wedding (550 Attendees) ---");
        WeddingEvent mediumWedding = new WeddingEvent("The Elegant Estate", true); // Photographer assigned
        addAttendeesWithPreferences(mediumWedding, 550, 300, 250); // 300 Basic, 250 Vegan
        displayEventCosts(mediumWedding, costCalculator);
        // Expected Catering: (300 * 2.00) + (250 * 2.50) = 600.00 + 625.00 = 1225.00
        // Expected Photography: 550 * 1.00 = 550.00
        // Expected Total: 1225.00 + 550.00 = 1775.00

        // --- Scenario 4: Edge Case - Zero Attendees ---
        System.out.println("\n--- Scenario 4: Edge Case - Zero Attendees ---");
        WeddingEvent zeroAttendeeWedding = new WeddingEvent("Empty Hall", true); // Photographer assigned
        // No attendees added
        displayEventCosts(zeroAttendeeWedding, costCalculator);
        // Expected Catering: 0.00
        // Expected Photography: 0.00
        // Expected Total: 0.00

        // --- Scenario 5: Edge Case - Photographer Not Assigned ---
        System.out.println("\n--- Scenario 5: Edge Case - Photographer Not Assigned (150 Attendees) ---");
        WeddingEvent noPhotographerWedding = new WeddingEvent("Community Hall", false); // Photographer NOT assigned
        addAttendeesWithPreferences(noPhotographerWedding, 150, 100, 50); // 100 Basic, 50 Vegan
        displayEventCosts(noPhotographerWedding, costCalculator);
        // Expected Catering: (100 * 3.00) + (50 * 3.50) = 300.00 + 175.00 = 475.00
        // Expected Photography: 0.00 (because not assigned)
        // Expected Total: 475.00 + 0.00 = 475.00
        
        // --- Scenario 6: Edge Case - Invalid Venue Data (Handled by WeddingEvent constructor) ---
        System.out.println("\n--- Scenario 6: Edge Case - Invalid Venue Data (Attempt) ---");
        try {
            // This should throw an IllegalArgumentException from WeddingEvent constructor
            WeddingEvent invalidVenueWedding = new WeddingEvent(null, true); 
            // The following line should not be reached if exception is thrown
            displayEventCosts(invalidVenueWedding, costCalculator); 
        } catch (IllegalArgumentException e) {
            System.out.println("Successfully caught expected error: " + e.getMessage());
        }
        try {
            // This should also throw an IllegalArgumentException
            WeddingEvent emptyVenueWedding = new WeddingEvent("   ", true); 
            // The following line should not be reached
            displayEventCosts(emptyVenueWedding, costCalculator); 
        } catch (IllegalArgumentException e) {
            System.out.println("Successfully caught expected error: " + e.getMessage());
        }

        // --- Scenario 7: Edge Case - Missing Meal Preferences (Handled by WeddingEvent.addAttendee) ---
        // The WeddingEvent.addAttendee method requires a MealType, so an attendee cannot be
        // added without a preference. If a Person object existed but wasn't added via
        // addAttendee, they wouldn't be part of meal counts. Our current design ensures
        // every "counted" attendee for meals has a preference.
        System.out.println("\n--- Scenario 7: Edge Case - Missing Meal Preferences ---");
        System.out.println("Note: The system design (WeddingEvent.addAttendee) requires a meal preference");
        System.out.println("for each attendee added to the event, fulfilling the 'each attendee selects");
        System.out.println("exactly one meal type' rule. Thus, 'missing meal preferences' for an");
        System.out.println("event-counted attendee is prevented by design.");
        WeddingEvent testEvent = new WeddingEvent("Test Venue", true);
        Person p1 = new Person("Attendee Without Explicit Preference Add");
        // The line below would cause a compile error if we tried to call an addAttendee version
        // that doesn't take MealType, or a runtime error if MealType was null.
        // testEvent.addAttendee(p1, null); // This would throw IllegalArgumentException
        try {
            testEvent.addAttendee(p1, null);
        } catch (IllegalArgumentException e) {
            System.out.println("Successfully caught expected error when adding attendee with null meal type: " + e.getMessage());
        }


        System.out.println("\n========================================================");
        System.out.println("Demonstration Complete.");
    }

    /**
     * Helper method to add a specified number of attendees with distributed meal preferences
     * to a wedding event.
     *
     * @param event The WeddingEvent to add attendees to.
     * @param totalAttendees The total number of attendees to add.
     * @param numBasicMeals The number of attendees who will select a Basic meal.
     * @param numVeganMeals The number of attendees who will select a Vegan meal.
     * Bob-Complete's Note: This utility simplifies setting up test scenarios.
     * It ensures that numBasicMeals + numVeganMeals == totalAttendees.
     */
    private static void addAttendeesWithPreferences(WeddingEvent event, int totalAttendees, int numBasicMeals, int numVeganMeals) {
        if (numBasicMeals + numVeganMeals != totalAttendees) {
            System.err.println("Error in test setup: Mismatch in meal counts for " + event.getVenue());
            // For a real test, this would be an assertion failure.
            // For demonstration, we'll proceed but log error.
            // To be robust, one might throw an exception here.
            // throw new IllegalArgumentException("Sum of basic and vegan meals must equal total attendees for test setup.");
        }
        if (event == null) return;

        List<Person> personsToAdd = new ArrayList<>();
        for (int i = 0; i < totalAttendees; i++) {
            // Create unique enough person names for this demo
            personsToAdd.add(new Person("Attendee " + (i + 1) + " (" + event.getEventId().substring(0,4) + ")"));
        }

        int basicAdded = 0;
        int veganAdded = 0;

        for (Person person : personsToAdd) {
            try {
                if (basicAdded < numBasicMeals) {
                    event.addAttendee(person, MealType.BASIC);
                    basicAdded++;
                } else if (veganAdded < numVeganMeals) {
                    event.addAttendee(person, MealType.VEGAN);
                    veganAdded++;
                } else {
                    // This case should ideally not be reached if counts are correct.
                    // Default to BASIC if counts are mismatched but we still have people.
                    event.addAttendee(person, MealType.BASIC); 
                }
            } catch (IllegalArgumentException e) {
                // This might happen if we try to add the same Person object instance multiple times
                // if the Person generation logic isn't creating truly new objects or if IDs collide.
                // Our current Person constructor with UUID should prevent this for new instances.
                System.err.println("Error adding attendee " + person.getName() + ": " + e.getMessage());
            }
        }
    }

    /**
     * Helper method to display the calculated costs for a given wedding event.
     *
     * @param event The WeddingEvent.
     * @param calculator The EventCostCalculator instance.
     * Bob-Complete's Note: Centralizes the output logic for neatness.
     */
    private static void displayEventCosts(WeddingEvent event, EventCostCalculator calculator) {
        if (event == null || calculator == null) {
            System.out.println("Cannot display costs: Event or calculator is null.");
            return;
        }
        System.out.println("Calculating costs for: " + event.getVenue() + " (ID: " + event.getEventId() + ")");
        System.out.println("Total Attendees: " + event.getAttendeeCount());
        System.out.println("  - Basic Meals: " + event.getMealCount(MealType.BASIC));
        System.out.println("  - Vegan Meals: " + event.getMealCount(MealType.VEGAN));
        System.out.println("  - Photographer Assigned: " + event.isPhotographerAssigned());

        EventCostSummary summary = calculator.calculateTotalEventCost(event);

        System.out.printf("  - Catering Cost: €%.2f%n", summary.getCateringCost());
        System.out.printf("  - Photography Cost: €%.2f%n", summary.getPhotographyCost());
        System.out.printf("  - TOTAL EVENT COST: €%.2f%n", summary.getTotalEventCost());
    }
}