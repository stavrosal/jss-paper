package com.weddingapp.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Represents a single Wedding Event, containing all relevant details
 * such as venue, attendees, their meal preferences, and photographer assignment.
 * This class is central to the event modeling system.
 * 
 * Bob-Complete's Design Notes:
 * - Venue: Stored as a String. Basic validation (non-null/empty) is applied.
 * - Attendees & Meal Selections: Two lists are maintained. `attendees` stores Person objects,
 *   and `mealSelections` stores CateringPreferences. The `addAttendee` method ensures
 *   these are kept consistent. This separation allows for clarity, though in some designs,
 *   the Person object itself might hold its meal preference for a specific event.
 *   Our current approach using CateringPreferences objects is flexible.
 * - Photographer Assignment: A simple boolean flag.
 * - Immutability of Collections: Getters for lists return unmodifiable views to protect
 *   the internal state of the WeddingEvent from external modification, promoting robustness.
 */
public class WeddingEvent {
    private final String eventId; // Unique ID for the event
    private String venue;
    private final List<Person> attendees;
    private final List<CateringPreferences> mealSelections;
    private boolean photographerAssigned; // Default could be true if photography is always included

    /**
     * Constructs a new WeddingEvent.
     *
     * @param venue The venue for the wedding. Must not be null or empty.
     * @param photographerAssigned Whether a photographer is assigned for the event's costing.
     * @throws IllegalArgumentException if the venue is null or empty.
     */
    public WeddingEvent(String venue, boolean photographerAssigned) {
        if (venue == null || venue.trim().isEmpty()) {
            throw new IllegalArgumentException("Venue cannot be null or empty.");
        }
        this.eventId = java.util.UUID.randomUUID().toString();
        this.venue = venue;
        this.attendees = new ArrayList<>();
        this.mealSelections = new ArrayList<>();
        this.photographerAssigned = photographerAssigned;
    }

    /**
     * Gets the unique ID of the event.
     * @return The event ID.
     */
    public String getEventId() {
        return eventId;
    }

    /**
     * Gets the venue of the wedding event.
     * @return The venue name/description.
     */
    public String getVenue() {
        return venue;
    }

    /**
     * Sets the venue for the wedding event.
     * @param venue The new venue. Must not be null or empty.
     * @throws IllegalArgumentException if the venue is null or empty.
     */
    public void setVenue(String venue) {
        if (venue == null || venue.trim().isEmpty()) {
            throw new IllegalArgumentException("Venue cannot be null or empty.");
        }
        this.venue = venue;
    }

    /**
     * Checks if a photographer is assigned for costing purposes.
     * @return true if a photographer is assigned, false otherwise.
     */
    public boolean isPhotographerAssigned() {
        return photographerAssigned;
    }

    /**
     * Sets whether a photographer is assigned for costing purposes.
     * @param photographerAssigned true to assign a photographer, false otherwise.
     */
    public void setPhotographerAssigned(boolean photographerAssigned) {
        this.photographerAssigned = photographerAssigned;
    }

    /**
     * Adds an attendee to the event along with their meal preference.
     * This method ensures that both the attendee list and meal selections list are updated.
     * It prevents adding a null person or a null meal type.
     *
     * Bob-Complete's Note: This method is crucial for maintaining data integrity.
     * It ensures every attendee added also has a meal preference recorded,
     * aligning with the "Each attendee selects exactly one meal type" rule.
     * It also prevents adding the same Person object multiple times to the attendee list.
     *
     * @param person The person attending. Must not be null.
     * @param mealType The meal type selected by the person. Must not be null.
     * @throws IllegalArgumentException if person or mealType is null, or if the person is already added.
     */
    public void addAttendee(Person person, MealType mealType) {
        if (person == null) {
            throw new IllegalArgumentException("Cannot add a null person as an attendee.");
        }
        if (mealType == null) {
            throw new IllegalArgumentException("MealType cannot be null when adding an attendee.");
        }

        // Check if person (by ID) is already in the attendees list
        // This prevents duplicate Person objects if uniqueness is desired.
        // If Person objects are always new instances even for the same individual,
        // this check might need to be based on person.getId().
        // For simplicity, we check object reference and ID.
        boolean alreadyExists = attendees.stream().anyMatch(p -> p.getId().equals(person.getId()));
        if (alreadyExists) {
            // Or update preference if that's the desired behavior. For now, throw.
            throw new IllegalArgumentException("Attendee " + person.getName() + " (ID: " + person.getId() + ") is already added to the event.");
        }

        this.attendees.add(person);
        this.mealSelections.add(new CateringPreferences(person, mealType));
    }
    
    /**
     * Removes an attendee from the event. This will also remove their associated meal preference.
     *
     * @param person The person to remove. If null or not found, the method does nothing.
     * @return true if the attendee was removed, false otherwise.
     */
    public boolean removeAttendee(Person person) {
        if (person == null) {
            return false;
        }
        boolean removed = this.attendees.remove(person);
        if (removed) {
            this.mealSelections.removeIf(preference -> preference.getAttendee().equals(person));
        }
        return removed;
    }


    /**
     * Gets an unmodifiable list of all attendees.
     * Returning an unmodifiable list prevents external modification of the internal list.
     * @return An unmodifiable list of {@link Person} objects.
     */
    public List<Person> getAttendees() {
        return Collections.unmodifiableList(attendees);
    }

    /**
     * Gets an unmodifiable list of all catering preferences (meal selections).
     * @return An unmodifiable list of {@link CateringPreferences} objects.
     */
    public List<CateringPreferences> getMealSelections() {
        return Collections.unmodifiableList(mealSelections);
    }

    /**
     * Gets the total number of attendees for the event.
     * @return The count of attendees.
     */
    public int getAttendeeCount() {
        return attendees.size();
    }

    /**
     * Gets the count of attendees who selected a specific meal type.
     *
     * @param mealType The meal type to count. Must not be null.
     * @return The number of attendees who selected the given meal type.
     * @throws IllegalArgumentException if mealType is null.
     */
    public long getMealCount(MealType mealType) {
        if (mealType == null) {
            throw new IllegalArgumentException("MealType cannot be null for counting.");
        }
        return mealSelections.stream()
                             .filter(preference -> preference.getSelectedMealType() == mealType)
                             .count();
    }

    @Override
    public String toString() {
        return "WeddingEvent{" +
               "eventId='" + eventId + '\'' +
               ", venue='" + venue + '\'' +
               ", attendeeCount=" + getAttendeeCount() +
               ", photographerAssigned=" + photographerAssigned +
               '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WeddingEvent that = (WeddingEvent) o;
        return Objects.equals(eventId, that.eventId); // Equality based on eventId
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventId); // Hash code based on eventId
    }
}