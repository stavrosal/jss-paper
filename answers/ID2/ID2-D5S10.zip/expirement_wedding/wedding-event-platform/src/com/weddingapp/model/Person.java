package com.weddingapp.model;

import java.util.Objects;
import java.util.UUID; // Using UUID for a simple unique ID

/**
 * Represents a person attending the wedding event.
 * This is a basic implementation as per the "pre-implemented" requirement.
 * It includes essential attributes like an ID and a name.
 * 
 * Bob-Complete's Note: In a real-world scenario, this class might have more attributes
 * (e.g., contact details, age, relationship to the couple). For our cost calculation
 * system, ID and name are sufficient for identification and context.
 * We include `equals` and `hashCode` based on `id` for proper collection management,
 * which is a good practice even for simpler models.
 */
public class Person {
    private final String id; // Unique identifier for the person
    private String name;

    /**
     * Constructs a new Person with a unique ID and a given name.
     * 
     * @param name The name of the person. Must not be null or empty.
     * @throws IllegalArgumentException if the name is null or empty.
     */
    public Person(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Person name cannot be null or empty.");
        }
        this.id = UUID.randomUUID().toString(); // Auto-generate a unique ID
        this.name = name;
    }

    /**
     * Constructs a new Person with a specific ID and name.
     * Useful if IDs are managed externally or for testing.
     * 
     * @param id The unique ID of the person. Must not be null or empty.
     * @param name The name of the person. Must not be null or empty.
     * @throws IllegalArgumentException if id or name is null or empty.
     */
    public Person(String id, String name) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Person ID cannot be null or empty.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Person name cannot be null or empty.");
        }
        this.id = id;
        this.name = name;
    }

    /**
     * Gets the unique ID of the person.
     * @return The person's ID.
     */
    public String getId() {
        return id;
    }

    /**
     * Gets the name of the person.
     * @return The person's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the person.
     * @param name The new name for the person. Must not be null or empty.
     * @throws IllegalArgumentException if the name is null or empty.
     */
    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Person name cannot be null or empty.");
        }
        this.name = name;
    }

    @Override
    public String toString() {
        return "Person{id='" + id + "', name='" + name + "'}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return Objects.equals(id, person.id); // Equality based on ID
    }

    @Override
    public int hashCode() {
        return Objects.hash(id); // Hash code based on ID
    }
}