package com.weddingapp.service;

import com.weddingapp.model.WeddingEvent;

/**
 * Orchestrator service responsible for calculating the total cost of a wedding event.
 * It combines costs from various individual services like catering and photography.
 * 
 * Bob-Complete's Design Notes:
 * - This class demonstrates the orchestrator pattern, delegating specific cost
 *   calculations to specialized services. This promotes modularity and separation of concerns.
 * - It instantiates its dependent services (`CateringCostService`, `PhotographyCostService`).
 *   In a more complex application using a DI framework, these would be injected.
 * - Provides a single, clear method to get the comprehensive event cost.
 */
public class EventCostCalculator {

    private final CateringCostService cateringCostService;
    private final PhotographyCostService photographyCostService;

    /**
     * Constructs an EventCostCalculator, initializing the necessary sub-services.
     */
    public EventCostCalculator() {
        this.cateringCostService = new CateringCostService();
        this.photographyCostService = new PhotographyCostService();
    }
    
    /**
     * Constructs an EventCostCalculator with provided service instances.
     * This constructor is useful for testing or if services are managed externally.
     *
     * @param cateringCostService The service for calculating catering costs.
     * @param photographyCostService The service for calculating photography costs.
     * @throws IllegalArgumentException if any service is null.
     */
    public EventCostCalculator(CateringCostService cateringCostService, PhotographyCostService photographyCostService) {
        if (cateringCostService == null) {
            throw new IllegalArgumentException("CateringCostService cannot be null.");
        }
        if (photographyCostService == null) {
            throw new IllegalArgumentException("PhotographyCostService cannot be null.");
        }
        this.cateringCostService = cateringCostService;
        this.photographyCostService = photographyCostService;
    }


    /**
     * Calculates the total cost for the given wedding event.
     * This includes summing up costs from catering, photography, and any other
     * relevant services.
     *
     * @param event The {@link WeddingEvent} for which to calculate the total cost.
     *              Must not be null.
     * @return The total event cost as a double.
     * @throws IllegalArgumentException if the event is null.
     */
    public EventCostSummary calculateTotalEventCost(WeddingEvent event) {
        if (event == null) {
            throw new IllegalArgumentException("WeddingEvent cannot be null for total cost calculation.");
        }

        double cateringCost = cateringCostService.calculateCateringCost(event);
        double photographyCost = photographyCostService.calculatePhotographyCost(event);
        double totalCost = cateringCost + photographyCost;

        return new EventCostSummary(cateringCost, photographyCost, totalCost);
    }

    /**
     * A simple data class (or record in Java 14+) to hold the breakdown of event costs.
     * Bob-Complete's Note: Using a dedicated class for the summary improves readability
     * and type safety of the return value from calculateTotalEventCost.
     */
    public static class EventCostSummary {
        private final double cateringCost;
        private final double photographyCost;
        private final double totalEventCost;

        public EventCostSummary(double cateringCost, double photographyCost, double totalEventCost) {
            this.cateringCost = cateringCost;
            this.photographyCost = photographyCost;
            this.totalEventCost = totalEventCost;
        }

        public double getCateringCost() {
            return cateringCost;
        }

        public double getPhotographyCost() {
            return photographyCost;
        }

        public double getTotalEventCost() {
            return totalEventCost;
        }

        @Override
        public String toString() {
            return String.format(
                "EventCostSummary { Catering=€%.2f, Photography=€%.2f, Total=€%.2f }",
                cateringCost, photographyCost, totalEventCost
            );
        }
    }
}