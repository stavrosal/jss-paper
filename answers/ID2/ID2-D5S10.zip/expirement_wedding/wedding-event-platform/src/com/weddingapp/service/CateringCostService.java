package com.weddingapp.service;

import com.weddingapp.model.MealType;
import com.weddingapp.model.WeddingEvent;
// No need to import CateringPreferences directly if we use event.getMealCount()

/**
 * Service class responsible for calculating catering costs for a wedding event.
 * It applies business rules based on attendee count and meal preferences.
 * 
 * Bob-Complete's Design Notes:
 * - Pricing constants are defined directly within this class for locality and clarity.
 * - The core logic determines the pricing tier based on total attendees, then calculates
 *   costs for each meal type separately before summing them up.
 * - Adherence to DRY: Helper methods `getBasicMealPricePerPerson` and `getVeganMealPricePerPerson`
 *   encapsulate the tier-based price lookup logic.
 * - Robustness: Handles the edge case of zero attendees gracefully (cost will be 0).
 *   Relies on WeddingEvent to provide accurate meal counts.
 */
public class CateringCostService {

    // --- Catering Pricing Constants ---
    // Attendee thresholds
    private static final int CATERING_VOLUME_DISCOUNT_THRESHOLD = 500;

    // Standard Pricing (<= 500 attendees)
    private static final double STANDARD_BASIC_MEAL_PRICE = 3.00;
    private static final double STANDARD_VEGAN_MEAL_PRICE = 3.50;

    // Volume Discount Pricing (> 500 attendees)
    private static final double VOLUME_BASIC_MEAL_PRICE = 2.00;
    private static final double VOLUME_VEGAN_MEAL_PRICE = 2.50;

    /**
     * Calculates the total catering cost for the given wedding event.
     * The cost is determined by the number of attendees selecting each meal type
     * and the applicable pricing tier (standard or volume discount).
     *
     * @param event The {@link WeddingEvent} for which to calculate catering costs.
     *              Must not be null.
     * @return The total catering cost as a double.
     * @throws IllegalArgumentException if the event is null.
     */
    public double calculateCateringCost(WeddingEvent event) {
        if (event == null) {
            throw new IllegalArgumentException("WeddingEvent cannot be null for catering cost calculation.");
        }

        int totalAttendees = event.getAttendeeCount();

        // Bob-Complete's Note: Using event.getMealCount() is efficient as it leverages
        // the stream-based counting already implemented in WeddingEvent.
        long basicMealCount = event.getMealCount(MealType.BASIC);
        long veganMealCount = event.getMealCount(MealType.VEGAN);

        // Ensure consistency: total attendees should match sum of meal counts
        // This is more of an assertion of the WeddingEvent's integrity.
        if (totalAttendees != (basicMealCount + veganMealCount) && totalAttendees > 0) {
            // This situation implies an issue with WeddingEvent's internal consistency
            // or how attendees/preferences are managed. For a robust system,
            // this might log a warning or throw a specific internal state exception.
            // For now, we'll proceed, but it's a point of attention.
            // System.err.println("Warning: Total attendee count does not match sum of meal counts. Check WeddingEvent logic.");
        }
        
        // If there are no attendees, the cost is zero.
        if (totalAttendees == 0) {
            return 0.0;
        }

        double basicMealPricePerPerson = getBasicMealPricePerPerson(totalAttendees);
        double veganMealPricePerPerson = getVeganMealPricePerPerson(totalAttendees);

        double totalBasicMealCost = basicMealCount * basicMealPricePerPerson;
        double totalVeganMealCost = veganMealCount * veganMealPricePerPerson;

        return totalBasicMealCost + totalVeganMealCost;
    }

    /**
     * Helper method to get the price for a basic meal based on the total attendee count.
     * Encapsulates the pricing tier logic for basic meals.
     *
     * @param totalAttendees The total number of attendees at the event.
     * @return The price per basic meal.
     */
    private double getBasicMealPricePerPerson(int totalAttendees) {
        if (totalAttendees > CATERING_VOLUME_DISCOUNT_THRESHOLD) {
            return VOLUME_BASIC_MEAL_PRICE;
        } else {
            return STANDARD_BASIC_MEAL_PRICE;
        }
    }

    /**
     * Helper method to get the price for a vegan meal based on the total attendee count.
     * Encapsulates the pricing tier logic for vegan meals.
     *
     * @param totalAttendees The total number of attendees at the event.
     * @return The price per vegan meal.
     */
    private double getVeganMealPricePerPerson(int totalAttendees) {
        if (totalAttendees > CATERING_VOLUME_DISCOUNT_THRESHOLD) {
            return VOLUME_VEGAN_MEAL_PRICE;
        } else {
            return STANDARD_VEGAN_MEAL_PRICE;
        }
    }
}