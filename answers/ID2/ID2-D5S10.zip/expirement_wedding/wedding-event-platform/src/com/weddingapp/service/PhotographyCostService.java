package com.weddingapp.service;

import com.weddingapp.model.WeddingEvent;

/**
 * Service class responsible for calculating photography costs for a wedding event.
 * Costs are based on the total number of attendees and whether a photographer is assigned.
 * 
 * Bob-Complete's Design Notes:
 * - Pricing constants for photography are defined within this class.
 * - The logic first checks if a photographer is even part of the event's costing.
 * - If a photographer is assigned, it applies a per-attendee rate based on volume.
 * - Handles zero attendees gracefully.
 */
public class PhotographyCostService {

    // --- Photography Pricing Constants ---
    // Attendee thresholds
    private static final int PHOTOGRAPHY_VOLUME_DISCOUNT_THRESHOLD = 600;

    // Standard Rate (<= 600 attendees)
    private static final double STANDARD_PHOTOGRAPHY_RATE_PER_ATTENDEE = 1.00;

    // Volume Discount Rate (> 600 attendees)
    private static final double VOLUME_PHOTOGRAPHY_RATE_PER_ATTENDEE = 0.75;

    /**
     * Calculates the total photography cost for the given wedding event.
     * If no photographer is assigned to the event, the cost is 0.
     * Otherwise, the cost is based on the total number of attendees and
     * the applicable pricing tier.
     *
     * @param event The {@link WeddingEvent} for which to calculate photography costs.
     *              Must not be null.
     * @return The total photography cost as a double.
     * @throws IllegalArgumentException if the event is null.
     */
    public double calculatePhotographyCost(WeddingEvent event) {
        if (event == null) {
            throw new IllegalArgumentException("WeddingEvent cannot be null for photography cost calculation.");
        }

        // If no photographer is assigned for the event, photography cost is zero.
        if (!event.isPhotographerAssigned()) {
            return 0.0;
        }

        int totalAttendees = event.getAttendeeCount();

        if (totalAttendees == 0) {
            return 0.0; // No attendees, no photography cost.
        }

        double photographyRatePerAttendee = getPhotographyRatePerAttendee(totalAttendees);
        return totalAttendees * photographyRatePerAttendee;
    }

    /**
     * Helper method to get the photography rate per attendee based on the total attendee count.
     * Encapsulates the pricing tier logic for photography.
     *
     * @param totalAttendees The total number of attendees at the event.
     * @return The photography rate per attendee.
     */
    private double getPhotographyRatePerAttendee(int totalAttendees) {
        if (totalAttendees > PHOTOGRAPHY_VOLUME_DISCOUNT_THRESHOLD) {
            return VOLUME_PHOTOGRAPHY_RATE_PER_ATTENDEE;
        } else {
            return STANDARD_PHOTOGRAPHY_RATE_PER_ATTENDEE;
        }
    }
}