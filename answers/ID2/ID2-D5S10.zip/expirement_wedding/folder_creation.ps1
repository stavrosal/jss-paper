# PowerShell Script to Create Project Directory Structure

$baseProjectDir = "wedding-event-platform"
$srcDir = Join-Path $baseProjectDir "src"
$comDir = Join-Path $srcDir "com"
$appDir = Join-Path $comDir "weddingapp"

$modelDir = Join-Path $appDir "model"
$serviceDir = Join-Path $appDir "service"
$utilDir = Join-Path $appDir "util"
$mainDir = Join-Path $appDir "main" # Changed from Main.java to main package
$docDir = Join-Path $baseProjectDir "doc"

# Create base project directory
if (-not (Test-Path $baseProjectDir)) {
    New-Item -ItemType Directory -Path $baseProjectDir
    Write-Host "Created directory: $baseProjectDir"
} else {
    Write-Host "Directory already exists: $baseProjectDir"
}

# Create src, com, weddingapp directories
New-Item -ItemType Directory -Force -Path $srcDir | Out-Null
New-Item -ItemType Directory -Force -Path $comDir | Out-Null
New-Item -ItemType Directory -Force -Path $appDir | Out-Null

# Create package directories
New-Item -ItemType Directory -Force -Path $modelDir | Out-Null
Write-Host "Ensured directory: $modelDir"
New-Item -ItemType Directory -Force -Path $serviceDir | Out-Null
Write-Host "Ensured directory: $serviceDir"
New-Item -ItemType Directory -Force -Path $utilDir | Out-Null
Write-Host "Ensured directory: $utilDir"
New-Item -ItemType Directory -Force -Path $mainDir | Out-Null
Write-Host "Ensured directory: $mainDir"

# Create doc directory
New-Item -ItemType Directory -Force -Path $docDir | Out-Null
Write-Host "Ensured directory: $docDir"

Write-Host "Project directory structure created/ensured successfully under '$baseProjectDir'."
Write-Host "You can now open the '$baseProjectDir' folder in VSCode."