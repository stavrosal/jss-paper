```markdown
# Wedding Event Management Platform - Cost Calculator

## 1. Project Overview

This project implements a core system for modeling wedding events and calculating associated costs, specifically for catering and photography services. The system is built in plain Java, without external build tools like Maven or Gradle, and is designed to be compiled and run using a standard JDK.

The primary objectives of this system are:
- To accurately model a `WeddingEvent` including venue, a list of attendees, their meal preferences, and photographer assignment.
- To calculate total catering costs based on the number of attendees, their selected meal types (Basic or Vegan), and tiered pricing (standard vs. volume discount).
- To calculate photography costs based on the total number of attendees and tiered pricing, contingent on a photographer being assigned.
- To provide a total event cost by combining catering and photography expenses.
- To handle specified edge cases gracefully, such as zero attendees, missing (prevented by design) meal preferences, and invalid venue data.

The system emphasizes clear separation between the data model (`com.weddingapp.model`) and business logic/services (`com.weddingapp.service`), adhering to principles of clean code, modularity, and robustness.

**Core Business Rules:**

**Catering Costs:**
-   Standard Pricing (≤500 attendees):
    -   Basic meal: €3.00 per person
    -   Vegan meal: €3.50 per person
-   Volume Discount Pricing (>500 attendees):
    -   Basic meal: €2.00 per person
    -   Vegan meal: €2.50 per person

**Photography Costs:**
-   Standard Rate (≤600 attendees):
    -   €1.00 per attendee
-   Volume Discount Rate (>600 attendees):
    -   €0.75 per attendee
-   Photography cost is €0.00 if no photographer is assigned to the event.

## 2. Project Structure

The project follows a standard Java package structure:

```
wedding-event-platform/
├── bin/                          # (Output directory for compiled .class files)
├── src/
│   └── com/
│       └── weddingapp/
│           ├── main/
│           │   └── Main.java             # Main application class for demonstration
│           ├── model/
│           │   ├── CateringPreferences.java # Links an attendee to their meal choice
│           │   ├── MealType.java         # Enum for Basic, Vegan meal types
│           │   ├── Person.java           # Represents an attendee
│           │   └── WeddingEvent.java     # Core data model for the event
│           └── service/
│               ├── CateringCostService.java # Logic for catering costs
│               ├── EventCostCalculator.java # Orchestrates total cost calculation
│               │                             # (Contains EventCostSummary inner class)
│               └── PhotographyCostService.java# Logic for photography costs
└── README.md                     # This file (or in doc/README.md)
```

-   **`src/com/weddingapp/model`**: Contains the data model classes that define the structure of a wedding event and its components.
-   **`src/com/weddingapp/service`**: Contains service classes that encapsulate the business logic for cost calculations.
-   **`src/com/weddingapp/main`**: Contains the `Main` class, which serves as the entry point for demonstrating the system's functionality.
-   **`bin/`**: This directory will be created during compilation to store the compiled `.class` files.

## 3. Setup and Prerequisites

-   **Java Development Kit (JDK):** Version 8 or higher is required. Ensure `javac` (compiler) and `java` (runtime) are in your system's PATH.
-   **Text Editor/IDE:** Any text editor can be used. VSCode with the "Language Support for Java(TM) by Red Hat" and "Debugger for Java" extensions (part of the "Java Extension Pack" by Microsoft) is recommended for a smoother development experience.

No external libraries or build tools (Maven, Gradle) are needed.

## 4. Compilation and Execution

Open a terminal or command prompt at the root directory of the project (`wedding-event-platform/`).

**Step 1: Compile the Java Source Files**

First, ensure the output directory for compiled classes (`bin/`) exists. If not, create it:
```bash
# For PowerShell:
if (-not (Test-Path "bin")) { New-Item -ItemType Directory -Path "bin" }

# For Bash (Linux/macOS/Git Bash):
mkdir -p bin
```

Then, navigate into the `src` directory and compile all `.java` files, placing the output `.class` files into the `../bin` directory:
```bash
cd src
javac -d ../bin com/weddingapp/model/*.java com/weddingapp/service/*.java com/weddingapp/main/*.java
cd .. 
```
*(Alternatively, from the project root, you might use a command like `javac -d bin src/com/weddingapp/model/*.java src/com/weddingapp/service/*.java src/com/weddingapp/main/*.java` depending on your shell and preference for pathing.)*

If you are using VSCode with the Java Extension Pack, it often handles compilation automatically when you attempt to run the `Main.java` file, or you can trigger a build task.

**Step 2: Run the Application**

Once compilation is successful, run the `Main` class from the project root directory:
```bash
java -cp bin com.weddingapp.main.Main
```
-   `-cp bin` (classpath) tells Java to look for compiled classes in the `bin` directory.
-   `com.weddingapp.main.Main` is the fully qualified name of the main class.

## 5. Example Usage and Output

Running the `Main` class will execute several predefined scenarios demonstrating the cost calculation for different wedding event configurations. The output will display:
-   The details of each scenario (venue, attendee counts, meal distributions, photographer status).
-   The calculated catering cost.
-   The calculated photography cost.
-   The total event cost.

**Example Output Snippet (for a small wedding):**
```
--- Scenario 1: Small Wedding (100 Attendees) ---
Calculating costs for: The Cozy Corner Chapel (ID: ...)
Total Attendees: 100
  - Basic Meals: 70
  - Vegan Meals: 30
  - Photographer Assigned: true
  - Catering Cost: €315.00
  - Photography Cost: €100.00
  - TOTAL EVENT COST: €415.00
```
The program will also demonstrate handling of edge cases like zero attendees, photographer not assigned, and attempts to use invalid data (which are caught and reported).

## 6. Design Principles ("Bob-Complete" Philosophy)

This project was developed adhering to a set of guiding principles focused on:
-   **Clarity and Simplicity (KISS):** Prioritizing straightforward and understandable code.
-   **Structured and Modular Design:** Organizing code into logical, cohesive units (classes and packages) with clear responsibilities.
-   **Readable and Maintainable Code:** Emphasizing descriptive naming, concise methods, and strategic commenting (including Javadoc).
-   **Configuration-Driven Business Logic:** Defining business rules (prices, thresholds) as easily identifiable and modifiable constants.
-   **Robustness and Predictable Behavior:** Gracefully handling edge cases and validating inputs.
-   **Pragmatic Development (YAGNI):** Implementing only what is necessary to meet current requirements.
-   **DRY (Don't Repeat Yourself):** Encapsulating repeated logic into helper methods.

---
```

