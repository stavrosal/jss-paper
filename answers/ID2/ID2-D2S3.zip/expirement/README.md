# Warehouse Management System

This project implements a simple warehouse management system in Java. It allows individual warehouses to manage their product stock, process orders, and calculate the total cost of orders including Value Added Tax (VAT).

## Project Overview

The system is designed for a global company with multiple warehouses. Each warehouse can be designated as either "local" or "central," which, along with a specific VAT category (REDUCED, NORMAL, EXTRA), determines the VAT rate applied to orders.

Core functionalities include:
- Tracking items in stock.
- Adding items to orders (which removes them from stock).
- Calculating the total cost of orders, including VAT.

## Features

-   **Item Management:** `Item` class with unique ID, name, and price.
-   **Warehouse Entity:** `Warehouse` class to manage stock (`items`) and `orders`.
    -   Attributes: name, type (`LOCAL`/`CENTRAL`), VAT category (`REDUCED`/`NORMAL`/`EXTRA`).
    -   Methods: `addStockItem()`, `addOrder()`, `calcCost()`.
-   **VAT Calculation:**
    -   VAT rates are configurable (currently via `AppConfig.java`).
    -   `VatService` interface provides abstraction for VAT rate retrieval.
    -   `AppConfigVatService` is the current implementation using `AppConfig`.
-   **Logging:** Uses SLF4J with Logback for application logging.
-   **Unit Tests:** Comprehensive JUnit 5 tests for core components.
-   **Build Management:** Uses Apache Maven for dependency management and building.

## Project Structure

-   `src/main/java`: Contains the main application source code.
    -   `com.globalcompany.warehouse.app`: Main application class (`App.java`).
    -   `com.globalcompany.warehouse.config`: Configuration classes (`AppConfig.java`).
    -   `com.globalcompany.warehouse.enums`: Enumerations for types (`WarehouseType`, `VatCategory`).
    -   `com.globalcompany.warehouse.exception`: Custom exception classes.
    -   `com.globalcompany.warehouse.model`: Domain model classes (`Item`, `Warehouse`).
    -   `com.globalcompany.warehouse.service`: Service interfaces and implementations (`VatService`, `AppConfigVatService`).
-   `src/main/resources`: Contains resources like `logback.xml`.
-   `src/test/java`: Contains JUnit test classes.
-   `pom.xml`: Maven project configuration file.

## Prerequisites

-   Java Development Kit (JDK) 17 or higher.
-   Apache Maven 3.6.x or higher.

## How to Build

1.  Clone the repository (or ensure you have the project files).
2.  Open a terminal and navigate to the project's root directory.
3.  Run the Maven command:
    ```bash
    mvn clean install
    ```
    This will compile the code, run tests, and package the application into a JAR file in the `target` directory.

## How to Run

After a successful build (`mvn clean install`), you can run the demonstration application:

```bash
java -jar target/warehouse-management-system-1.0-SNAPSHOT-jar-with-dependencies.jar