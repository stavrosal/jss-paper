package com.globalcompany.warehouse.service;

import com.globalcompany.warehouse.config.AppConfig;
import com.globalcompany.warehouse.enums.VatCategory;
import com.globalcompany.warehouse.enums.WarehouseType;
import com.globalcompany.warehouse.exception.InvalidConfigurationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito; // If we were to mock AppConfig

import static org.junit.jupiter.api.Assertions.*;
// For mocking:
// import static org.mockito.Mockito.when;
// import static org.mockito.Mockito.mock;

/**
 * Unit tests for {@link AppConfigVatService}.
 *
 * Bob's Rationale: Tests the interaction between VatService implementation
 * and its configuration source (AppConfig).
 */
class AppConfigVatServiceTest {

    private AppConfig mockAppConfig; // We could mock AppConfig for more isolation
    private AppConfig realAppConfig;
    private VatService vatServiceWithRealConfig;
    // private VatService vatServiceWithMockConfig;


    @BeforeEach
    void setUp() {
        realAppConfig = new AppConfig();
        vatServiceWithRealConfig = new AppConfigVatService(realAppConfig);

        // Example of mocking AppConfig (optional, but good for true unit testing of service)
        // mockAppConfig = mock(AppConfig.class);
        // vatServiceWithMockConfig = new AppConfigVatService(mockAppConfig);
    }

    @Test
    void constructor_NullAppConfig_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> new AppConfigVatService(null));
    }

    @Test
    void getVatRate_ValidCombination_ReturnsCorrectRate_UsingRealAppConfig() {
        // Test with real AppConfig to ensure integration
        double rate = vatServiceWithRealConfig.getVatRate(WarehouseType.LOCAL, VatCategory.NORMAL);
        assertEquals(0.10, rate, 0.001); // Assuming 0.10 is the configured rate
    }

    @Test
    void getVatRate_AppConfigThrowsException_ServiceWrapsInInvalidConfigurationException() {
        // To test this, we need AppConfig to throw an exception.
        // The current AppConfig throws InvalidConfigurationException directly if a key is missing.
        // So, AppConfigVatService doesn't really "wrap" it anymore, it just propagates.
        // Let's adjust the test to reflect that the service propagates InvalidConfigurationException.

        // Create a scenario where AppConfig would throw.
        // This requires a combination not in AppConfig, which is hard with current exhaustive config.
        // If AppConfig was modified to miss a rate, e.g., for a new enum value:
        // enum HypotheticalCategory { NEW_CAT }
        // AppConfig tempConfig = new AppConfig(); // that doesn't have NEW_CAT
        // VatService service = new AppConfigVatService(tempConfig);
        // assertThrows(InvalidConfigurationException.class, () -> {
        //     service.getVatRate(WarehouseType.LOCAL, HypotheticalCategory.NEW_CAT);
        // });

        // For now, let's assume AppConfig's own test (`AppConfigTest`) covers its exception throwing.
        // The main purpose of this test for AppConfigVatService is to ensure it calls AppConfig.
        // If we were mocking AppConfig:
        // when(mockAppConfig.getVatRate(WarehouseType.LOCAL, VatCategory.REDUCED))
        //    .thenThrow(new IllegalArgumentException("Simulated config error"));
        // assertThrows(InvalidConfigurationException.class,
        //    () -> vatServiceWithMockConfig.getVatRate(WarehouseType.LOCAL, VatCategory.REDUCED));

        // Since AppConfig now throws InvalidConfigurationException directly,
        // and AppConfigVatService catches IllegalArgumentException and wraps it,
        // this test needs to ensure that if AppConfig *somehow* threw IllegalArgumentException,
        // it would be wrapped.
        // This is a bit contrived now. The more direct test is that it propagates InvalidConfigurationException.

        // Let's test the propagation of InvalidConfigurationException from AppConfig
        // This requires a mock AppConfig that throws InvalidConfigurationException
        AppConfig failingMockAppConfig = Mockito.mock(AppConfig.class);
        Mockito.when(failingMockAppConfig.getVatRate(WarehouseType.LOCAL, VatCategory.REDUCED))
               .thenThrow(new InvalidConfigurationException("Rate not found in mock"));
        
        VatService serviceWithFailingMock = new AppConfigVatService(failingMockAppConfig);

        assertThrows(InvalidConfigurationException.class, 
            () -> serviceWithFailingMock.getVatRate(WarehouseType.LOCAL, VatCategory.REDUCED),
            "Service should propagate InvalidConfigurationException from AppConfig.");
    }
}