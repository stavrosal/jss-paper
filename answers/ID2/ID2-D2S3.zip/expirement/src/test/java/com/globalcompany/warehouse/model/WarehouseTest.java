package com.globalcompany.warehouse.model;

import com.globalcompany.warehouse.config.AppConfig;
import com.globalcompany.warehouse.enums.VatCategory;
import com.globalcompany.warehouse.enums.WarehouseType;
// Import ItemNotFoundInStockException if you plan to throw it from addOrder
// import com.globalcompany.warehouse.exception.ItemNotFoundInStockException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

/**
 * Unit tests for the {@link Warehouse} class.
 *
 * Bob's Rationale: Testing the Warehouse class is crucial as it orchestrates
 * item management and cost calculation. Tests cover construction, stock management,
 * order processing, and cost calculation logic, including VAT application.
 * (Principle #4.1.2)
 */
class WarehouseTest {

    private AppConfig appConfig;
    private Warehouse warehouse;
    private VatService vatService; 
    private Item item1;
    private Item item2;

    @BeforeEach
    void setUp() {
        appConfig = new AppConfig(); // Use the real AppConfig for these tests
        // For more isolated tests of Warehouse logic, AppConfig could be mocked.
        // But for now, using the real one is fine as its logic is simple.
        vatService = new AppConfigVatService(appConfig); // Create VatService instance

        warehouse = new Warehouse("Test Warehouse", WarehouseType.LOCAL, VatCategory.NORMAL, vatService); // Pass VatService
        item1 = new Item("Laptop", 1000.00);
        item2 = new Item("Mouse", 25.00);
    }

    @Test
    void testWarehouseCreation_Success() {
        assertEquals("Test Warehouse", warehouse.getName());
        assertEquals(WarehouseType.LOCAL, warehouse.getType());
        assertEquals(VatCategory.NORMAL, warehouse.getVatCategory());
        assertTrue(warehouse.getItems().isEmpty(), "New warehouse should have no items in stock.");
        assertTrue(warehouse.getOrders().isEmpty(), "New warehouse should have no orders.");
    }

    @Test
    void testWarehouseCreation_NullName_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> new Warehouse(null, WarehouseType.LOCAL, VatCategory.NORMAL, appConfig));
    }

    @Test
    void testWarehouseCreation_NullType_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> new Warehouse("Valid Name", null, VatCategory.NORMAL, appConfig));
    }

    @Test
    void testWarehouseCreation_NullVatCategory_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> new Warehouse("Valid Name", WarehouseType.LOCAL, null, appConfig));
    }

  


    @Test
    void testAddStockItem_Success() {
        warehouse.addStockItem(item1);
        assertEquals(1, warehouse.getItems().size(), "Stock should contain 1 item after adding.");
        assertTrue(warehouse.getItems().contains(item1), "Stock should contain the added item.");
    }

    @Test
    void testAddStockItem_NullItem_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> warehouse.addStockItem(null));
    }

    @Test
    void testGetItems_ReturnsUnmodifiableList() {
        warehouse.addStockItem(item1);
        List<Item> items = warehouse.getItems();
        assertThrows(UnsupportedOperationException.class, () -> items.add(item2),
                     "getItems() should return an unmodifiable list.");
    }

    @Test
    void testGetOrders_ReturnsUnmodifiableList() {
        warehouse.addStockItem(item1);
        warehouse.addOrder(item1); // Order the item
        List<Item> orders = warehouse.getOrders();
        assertThrows(UnsupportedOperationException.class, () -> orders.add(item2),
                     "getOrders() should return an unmodifiable list.");
    }


    @Test
    void testAddOrder_Success_ItemInStock() {
        warehouse.addStockItem(item1);
        warehouse.addStockItem(item2); // Add a second distinct item

        assertTrue(warehouse.addOrder(item1), "addOrder should return true for item in stock.");
        assertEquals(1, warehouse.getOrders().size(), "Orders list should contain 1 item.");
        assertTrue(warehouse.getOrders().contains(item1), "Orders list should contain the ordered item.");
        assertEquals(1, warehouse.getItems().size(), "Stock should have 1 item remaining.");
        assertFalse(warehouse.getItems().contains(item1), "Ordered item should be removed from stock.");
        assertTrue(warehouse.getItems().contains(item2), "Other item should still be in stock.");
    }

    @Test
    void testAddOrder_ItemNotInStock_ReturnsFalse() {
        warehouse.addStockItem(item1); // Stock only item1
        // item2 is created but not added to this warehouse's stock

        assertFalse(warehouse.addOrder(item2), "addOrder should return false for item not in stock.");
        assertTrue(warehouse.getOrders().isEmpty(), "Orders list should be empty if order failed.");
        assertEquals(1, warehouse.getItems().size(), "Stock count should not change if order failed.");
        assertTrue(warehouse.getItems().contains(item1), "Original stock item should still be present.");
    }

    @Test
    void testAddOrder_OrderLastItemInStock() {
        warehouse.addStockItem(item1);
        assertTrue(warehouse.addOrder(item1));
        assertTrue(warehouse.getItems().isEmpty(), "Stock should be empty after ordering the last item.");
        assertEquals(1, warehouse.getOrders().size());
    }

    @Test
    void testAddOrder_NullItem_ThrowsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> warehouse.addOrder(null));
    }

    @Test
    void testCalcCost_NoOrders() {
        assertEquals(0.0, warehouse.calcCost(), 0.001, "Cost should be 0 if no orders.");
    }

    @Test
    void testCalcCost_SingleOrder_LocalNormalVAT() {
        // Warehouse is LOCAL, NORMAL (VAT rate from AppConfig: 0.10 for LOCAL/NORMAL)
        warehouse.addStockItem(item1); // Laptop price 1000.00
        warehouse.addOrder(item1);

        double expectedSubtotal = 1000.00;
        double vatRate = vatService.getVatRate(WarehouseType.LOCAL, VatCategory.NORMAL); // Should be 0.10
        double expectedVat = expectedSubtotal * vatRate; // 1000.00 * 0.10 = 100.00
        double expectedTotalCost = expectedSubtotal + expectedVat; // 1000.00 + 100.00 = 1100.00

        assertEquals(expectedTotalCost, warehouse.calcCost(), 0.001, "Total cost for single order with LOCAL/NORMAL VAT is incorrect.");
    }

    @Test
    void testCalcCost_MultipleOrders_CentralExtraVAT() {
        VatService centralVatService = new AppConfigVatService(appConfig); // Assuming same appConfig
        Warehouse centralWarehouse = new Warehouse("Central Hub", WarehouseType.CENTRAL, VatCategory.EXTRA, centralVatService);
        // VAT rate from AppConfig for CENTRAL/EXTRA is 0.25

        Item productA = new Item("Product A", 100.00);
        Item productB = new Item("Product B", 50.00);

        centralWarehouse.addStockItem(productA);
        centralWarehouse.addStockItem(productB);

        centralWarehouse.addOrder(productA);
        centralWarehouse.addOrder(productB);

        double expectedSubtotal = 100.00 + 50.00; // 150.00
        double vatRate = centralVatService.getVatRate(WarehouseType.CENTRAL, VatCategory.EXTRA); // Should be 0.25
        double expectedVat = expectedSubtotal * vatRate; // 150.00 * 0.25 = 37.50
        double expectedTotalCost = expectedSubtotal + expectedVat; // 150.00 + 37.50 = 187.50

        assertEquals(expectedTotalCost, centralWarehouse.calcCost(), 0.001, "Total cost for multiple orders with CENTRAL/EXTRA VAT is incorrect.");
    }

    @Test
    void testCalcCost_OrderSameItemMultipleTimes_IfStockAllows() {
        // Warehouse is LOCAL, NORMAL (VAT rate 0.10)
        Item sharedItem = new Item("Shared Item", 200.00);
        // To order the "same" conceptual item, we need distinct instances in stock if Item.equals is by ID.
        // Or, if Item had a quantity, that would be different.
        // Our current Item.equals is by unique ID. So, to order "Shared Item" twice,
        // we need two distinct Item objects (with different IDs) representing "Shared Item" in stock.

        Item sharedItemInstance1 = new Item("Shared Item", 200.00);
        Item sharedItemInstance2 = new Item("Shared Item", 200.00); // Different ID from instance1

        warehouse.addStockItem(sharedItemInstance1);
        warehouse.addStockItem(sharedItemInstance2);

        warehouse.addOrder(sharedItemInstance1);
        warehouse.addOrder(sharedItemInstance2);

        double expectedSubtotal = 200.00 + 200.00; // 400.00
        double vatRate = appConfig.getVatRate(WarehouseType.LOCAL, VatCategory.NORMAL); // 0.10
        double expectedVat = expectedSubtotal * vatRate; // 400.00 * 0.10 = 40.00
        double expectedTotalCost = expectedSubtotal + expectedVat; // 400.00 + 40.00 = 440.00

        assertEquals(expectedTotalCost, warehouse.calcCost(), 0.001, "Cost incorrect when ordering multiple instances of conceptually similar items.");
        assertTrue(warehouse.getItems().isEmpty(), "Stock should be empty after ordering all instances.");
    }
}