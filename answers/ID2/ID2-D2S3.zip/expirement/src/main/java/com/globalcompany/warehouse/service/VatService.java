package com.globalcompany.warehouse.service;

import com.globalcompany.warehouse.enums.VatCategory;
import com.globalcompany.warehouse.enums.WarehouseType;

/**
 * Interface for a service that provides Value Added Tax (VAT) rates.
 * This abstraction allows for different implementations of VAT rate retrieval
 * (e.g., from config files, databases, external services) without changing
 * classes that consume VAT rates.
 *
 * Bob's Rationale: Using an interface for services promotes loose coupling
 * and testability (Principle #2 - Modularity, SRP). The Warehouse will depend
 * on this interface, not a concrete implementation.
 */
public interface VatService {

    /**
     * Retrieves the VAT rate applicable for a given warehouse type and VAT category.
     *
     * @param type The type of the warehouse (e.g., LOCAL, CENTRAL).
     * @param category The VAT category (e.g., REDUCED, NORMAL, EXTRA).
     * @return The applicable VAT rate as a decimal (e.g., 0.20 for 20%).
     * @throws com.globalcompany.warehouse.exception.InvalidConfigurationException if no rate is configured
     *         or another configuration issue occurs.
     */
    double getVatRate(WarehouseType type, VatCategory category);
}