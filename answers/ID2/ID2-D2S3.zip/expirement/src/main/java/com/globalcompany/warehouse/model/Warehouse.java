package com.globalcompany.warehouse.model;

import com.globalcompany.warehouse.enums.VatCategory;
import com.globalcompany.warehouse.enums.WarehouseType;
// Import custom exceptions once they are created
// import com.globalcompany.warehouse.exception.ItemNotFoundInStockException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

// It's good practice to import a logger
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Represents a warehouse that manages a stock of items and processes orders.
 * Each warehouse has a name, type (LOCAL or CENTRAL), and a VAT category,
 * which together determine VAT calculation policies.
 *
 * Bob's Rationale: This is the central class for warehouse operations.
 * It encapsulates the inventory (items) and orders. Methods for adding orders
 * and calculating costs will contain the core business logic (Principle #1.3).
 * Using unmodifiable lists for getters of collections is good practice for encapsulation.
 */
public class Warehouse {
    private static final Logger logger = LoggerFactory.getLogger(Warehouse.class);

    private final String name;
    private final List<Item> items; // Items currently in stock
    private final List<Item> orders; // Items that have been ordered
    private final WarehouseType type;
    private final VatCategory vatCategory;
    private final AppConfig appConfig; // Add this field

    /**
     * Constructs a new Warehouse.
     *
     * @param name The name of the warehouse. Must not be null or empty.
     * @param type The type of the warehouse (LOCAL or CENTRAL). Must not be null.
     * @param vatCategory The VAT category for this warehouse. Must not be null.
     * @throws IllegalArgumentException if any parameter is null or name is empty.
     */
    public Warehouse(String name, WarehouseType type, VatCategory vatCategory, AppConfig appConfig) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Warehouse name cannot be null or empty.");
        }
        if (type == null) {
            throw new IllegalArgumentException("Warehouse type cannot be null.");
        }
        if (vatCategory == null) {
            throw new IllegalArgumentException("Warehouse VAT category cannot be null.");
        }
        if (appConfig == null) {
        throw new IllegalArgumentException("AppConfig cannot be null.");
        }
        
        this.appConfig = appConfig; 
        this.name = name;
        this.type = type;
        this.vatCategory = vatCategory;
        this.items = new ArrayList<>();
        this.orders = new ArrayList<>();
        logger.info("Warehouse '{}' created. Type: {}, VAT Category: {}", name, type, vatCategory);
    }

    // --- Getters ---
    public String getName() {
        return name;
    }

    public WarehouseType getType() {
        return type;
    }

    public VatCategory getVatCategory() {
        return vatCategory;
    }

    /**
     * Returns an unmodifiable view of the items currently in stock.
     * @return An unmodifiable list of items in stock.
     */
    public List<Item> getItems() {
        return Collections.unmodifiableList(items);
    }

    /**
     * Returns an unmodifiable view of the items that have been ordered.
     * @return An unmodifiable list of ordered items.
     */
    public List<Item> getOrders() {
        return Collections.unmodifiableList(orders);
    }

    // --- Core Business Logic Methods (Stubs for now, to be implemented in Phase 2) ---

    /**
     * Adds an item to the warehouse's stock.
     *
     * @param item The item to add to stock. Must not be null.
     * @throws IllegalArgumentException if item is null.
     */
    public void addStockItem(Item item) {
        if (item == null) {
            logger.warn("Attempted to add a null item to stock in warehouse '{}'.", this.name);
            throw new IllegalArgumentException("Cannot add a null item to stock.");
        }
        this.items.add(item);
        logger.debug("Item '{}' added to stock in warehouse '{}'. Current stock count: {}", item.getName(), this.name, this.items.size());
    }

    /**
     * Adds an item to the orders list and removes it from the items (stock) list.
     * <p>
     * Bob's Note: This method will be fully implemented in Phase 2.2.2.
     * It will involve checking stock, removing the specific item instance,
     * and handling cases where the item is not found.
     * </p>
     *
     * @param itemToOrder The item to be ordered. Must not be null.
     * @return true if the order was successful, false otherwise (e.g., item not in stock).
     * @throws IllegalArgumentException if itemToOrder is null.
     * // @throws ItemNotFoundInStockException if the item is not found in stock (to be added).
     */
    public boolean addOrder(Item itemToOrder) {
        if (itemToOrder == null) {
            logger.warn("Attempted to order a null item in warehouse '{}'.", this.name);
            throw new IllegalArgumentException("Cannot order a null item.");
        }

        // Crucial: List.remove(Object) uses the equals() method of the Object.
        // Since our Item.equals() is based on ID, this will remove the specific instance if found.
        boolean removedFromStock = this.items.remove(itemToOrder);

        if (removedFromStock) {
            this.orders.add(itemToOrder);
            logger.info("Item '{}' (ID: {}) ordered from warehouse '{}'. Removed from stock.",
                        itemToOrder.getName(), itemToOrder.getId(), this.name);
            logger.debug("Current stock for '{}': {}, Orders for '{}': {}",
                         this.name, this.items.size(), this.name, this.orders.size());
            return true;
        } else {
            logger.warn("Failed to order item '{}' (ID: {}): Not found in stock in warehouse '{}'.",
                        itemToOrder.getName(), itemToOrder.getId(), this.name);
            // Later, we might throw ItemNotFoundInStockException here.
            // For now, returning false as per initial requirement structure.
            return false;
        }
    }

    /**
     * Calculates the total cost of all orders, including VAT.
     * <p>
     * Bob's Note: This method will be fully implemented in Phase 2.2.3.
     * It will involve summing item prices and applying VAT based on warehouse type and VAT category.
     * The VAT rates will come from a configuration or service.
     * </p>
     *
     * @return The total cost of orders including VAT.
     */
    public double calcCost() {
        // Placeholder for VAT rates - these will come from AppConfig or VatService
        // This is a simplified version for now. Full logic in Phase 2.
        double vatRate = 0.0; // Default, will be determined by type and category

        // Example: A very basic, non-configurable VAT logic for demonstration here.
        // THIS WILL BE REPLACED BY AppConfig/VatService in Phase 2.1
        if (this.type == WarehouseType.LOCAL && this.vatCategory == VatCategory.NORMAL) {
            vatRate = 0.10; // Example: 10% for Local Normal
        } else if (this.type == WarehouseType.CENTRAL && this.vatCategory == VatCategory.NORMAL) {
            vatRate = 0.20; // Example: 20% for Central Normal
        } else if (this.vatCategory == VatCategory.REDUCED) {
            vatRate = 0.05; // Example: 5% for any Reduced
        } else if (this.vatCategory == VatCategory.EXTRA) {
            vatRate = 0.25; // Example: 25% for any Extra
        }
        // Add more combinations as needed or make this data-driven.

        if (this.orders.isEmpty()) {
            logger.info("No orders in warehouse '{}' to calculate cost for.", this.name);
            return 0.0;
        }

        double subtotal = 0.0;
        for (Item orderItem : this.orders) {
            subtotal += orderItem.getPrice();
        }
        logger.debug("Subtotal for orders in warehouse '{}': {}", this.name, String.format("%.2f", subtotal));

        double vatAmount = subtotal * vatRate;
        double totalCost = subtotal + vatAmount;

        logger.info("Calculated total cost for warehouse '{}': Subtotal={}, VAT Rate={}, VAT Amount={}, Total={}",
                    this.name, String.format("%.2f", subtotal), String.format("%.2f", vatRate),
                    String.format("%.2f", vatAmount), String.format("%.2f", totalCost));

        return totalCost;
    }

    @Override
    public String toString() {
        return "Warehouse{" +
               "name='" + name + '\'' +
               ", type=" + type +
               ", vatCategory=" + vatCategory +
               ", itemsInStock=" + items.size() +
               ", ordersPlaced=" + orders.size() +
               '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Warehouse warehouse = (Warehouse) o;
        // Warehouses could be considered equal if their names are unique,
        // or a more complex combination of attributes. For now, name is a good candidate.
        return Objects.equals(name, warehouse.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}