package com.globalcompany.warehouse.config;

import com.globalcompany.warehouse.enums.VatCategory;
import com.globalcompany.warehouse.enums.WarehouseType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Manages application-wide configurations, such as VAT rates.
 * In a more complex application, this might load settings from external files
 * (e.g., .properties, .yaml).
 *
 * Bob's Rationale: Centralizing configuration, even if initially hardcoded,
 * makes it easier to manage and modify later (Principle #0.2, #7).
 * This class will provide VAT rates to the Warehouse or a VatService.
 */
public class AppConfig {
    private static final Logger logger = LoggerFactory.getLogger(AppConfig.class);

    // Using a nested class or record for the key makes the map more readable
    private static final class VatRateKey {
        final WarehouseType warehouseType;
        final VatCategory vatCategory;

        VatRateKey(WarehouseType warehouseType, VatCategory vatCategory) {
            this.warehouseType = warehouseType;
            this.vatCategory = vatCategory;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            VatRateKey that = (VatRateKey) o;
            return warehouseType == that.warehouseType && vatCategory == that.vatCategory;
        }

        @Override
        public int hashCode() {
            return Objects.hash(warehouseType, vatCategory);
        }
    }

    private final Map<VatRateKey, Double> vatRates;

    /**
     * Initializes the application configuration.
     * For now, VAT rates are hardcoded.
     */
    public AppConfig() {
        vatRates = new HashMap<>();
        // Populate VAT rates - These are examples and should be confirmed
        // LOCAL Warehouse VAT Rates
        vatRates.put(new VatRateKey(WarehouseType.LOCAL, VatCategory.REDUCED), 0.05); // 5%
        vatRates.put(new VatRateKey(WarehouseType.LOCAL, VatCategory.NORMAL), 0.10);  // 10%
        vatRates.put(new VatRateKey(WarehouseType.LOCAL, VatCategory.EXTRA), 0.18);   // 18%

        // CENTRAL Warehouse VAT Rates
        vatRates.put(new VatRateKey(WarehouseType.CENTRAL, VatCategory.REDUCED), 0.07); // 7%
        vatRates.put(new VatRateKey(WarehouseType.CENTRAL, VatCategory.NORMAL), 0.20);  // 20%
        vatRates.put(new VatRateKey(WarehouseType.CENTRAL, VatCategory.EXTRA), 0.25);   // 25%

        logger.info("AppConfig initialized with {} VAT rate entries.", vatRates.size());
    }

    /**
     * Retrieves the VAT rate for a given warehouse type and VAT category.
     *
     * @param type The type of the warehouse.
     * @param category The VAT category.
     * @return The applicable VAT rate as a decimal (e.g., 0.20 for 20%).
     * @throws IllegalArgumentException if no rate is configured for the given combination.
     */
    public double getVatRate(WarehouseType type, VatCategory category) {
        VatRateKey key = new VatRateKey(type, category);
        Double rate = vatRates.get(key);
        if (rate == null) {
            String errorMessage = String.format("No VAT rate configured for WarehouseType: %s, VatCategory: %s", type, category);
            logger.error(errorMessage);
            // In a real app, you might return a default or handle this more gracefully
            throw new IllegalArgumentException(errorMessage);
        }
        logger.debug("Retrieved VAT rate for Type: {}, Category: {} -> Rate: {}", type, category, rate);
        return rate;
    }

    // --- Placeholder for other configurations ---
    // public String getSomeOtherSetting() { return "someValue"; }
}