package com.globalcompany.warehouse.exception;

/**
 * Custom exception to indicate that an item requested for an operation
 * (e.g., ordering) was not found in the warehouse's current stock.
 *
 * Bob's Rationale: Specific exceptions provide better error handling context
 * than generic ones (Principle #2.3, #8).
 */
public class ItemNotFoundInStockException extends RuntimeException {
    public ItemNotFoundInStockException(String message) {
        super(message);
    }

    public ItemNotFoundInStockException(String message, Throwable cause) {
        super(message, cause);
    }
}