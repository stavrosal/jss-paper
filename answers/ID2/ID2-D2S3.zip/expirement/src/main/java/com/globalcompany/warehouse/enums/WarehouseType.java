package com.globalcompany.warehouse.enums;

/**
 * Represents the type of a warehouse, indicating its location category.
 * This affects policies such as VAT calculation.
 *
 * Bob's Rationale: Using enums for fixed sets of values improves type safety
 * and code readability compared to raw strings (Principle #1.2, #3).
 */
public enum WarehouseType {
    /**
     * A local warehouse, potentially subject to specific regional regulations.
     */
    LOCAL,

    /**
     * A central warehouse, often serving a larger region or acting as a hub.
     */
    CENTRAL
}