package com.globalcompany.warehouse.app;

import com.globalcompany.warehouse.config.AppConfig;
import com.globalcompany.warehouse.enums.VatCategory;
import com.globalcompany.warehouse.enums.WarehouseType;
import com.globalcompany.warehouse.model.Item;
import com.globalcompany.warehouse.model.Warehouse;
import com.globalcompany.warehouse.service.AppConfigVatService; // Import implementation
import com.globalcompany.warehouse.service.VatService;       // Import interface
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class App {
    private static final Logger logger = LoggerFactory.getLogger(App.class);

    public static void main(String[] args) {
        logger.info("Starting Warehouse Management System Demonstration (v2 with VatService)...");

        // 1. Initialize Configuration
        AppConfig config = new AppConfig();
        logger.info("Configuration loaded.");

        // 1b. Initialize VatService
        VatService vatService = new AppConfigVatService(config); // Create VatService instance
        logger.info("VatService initialized.");

        // 2. Create Items
        Item laptop = new Item("SuperDell Laptop", 1200.50);
        Item mouse = new Item("Logi Mouse", 25.99);
        Item keyboard = new Item("Mech Keyboard", 75.00);
        Item monitor = new Item("4K Monitor", 350.25);
        Item anotherLaptop = new Item("SuperDell Laptop", 1200.50); // A second distinct laptop instance

        logger.info("Created sample items...");
        logger.debug("Item 1: {}", laptop);
        logger.debug("Item 2: {}", mouse);
        logger.debug("Item 3: {}", keyboard);
        logger.debug("Item 4: {}", monitor);
        logger.debug("Item 5: {}", anotherLaptop);


        // 3. Create Warehouses using VatService
        Warehouse localWarehouse = new Warehouse("Local Tech Hub", WarehouseType.LOCAL, VatCategory.NORMAL, vatService);
        Warehouse centralWarehouse = new Warehouse("Central Distribution", WarehouseType.CENTRAL, VatCategory.REDUCED, vatService);
        logger.info("Created warehouse: {}", localWarehouse);
        logger.info("Created warehouse: {}", centralWarehouse);

        // 4. Stock Local Warehouse
        logger.info("--- Stocking Local Warehouse: {} ---", localWarehouse.getName());
        localWarehouse.addStockItem(laptop);
        localWarehouse.addStockItem(anotherLaptop); // Stocking the second distinct laptop
        localWarehouse.addStockItem(mouse);
        localWarehouse.addStockItem(keyboard);
        logger.info("Local Warehouse stock count: {}", localWarehouse.getItems().size());
        localWarehouse.getItems().forEach(item -> logger.debug("LW Stock: {}", item));

        // 4b. Stock Central Warehouse
        logger.info("--- Stocking Central Warehouse: {} ---", centralWarehouse.getName());
        centralWarehouse.addStockItem(monitor);
        centralWarehouse.addStockItem(new Item("Gaming Mouse", 55.00)); // New item directly
        centralWarehouse.addStockItem(new Item("Gaming Mouse", 55.00)); // Another gaming mouse
        logger.info("Central Warehouse stock count: {}", centralWarehouse.getItems().size());
        centralWarehouse.getItems().forEach(item -> logger.debug("CW Stock: {}", item));


        // 5. Simulate Orders in Local Warehouse
        logger.info("--- Simulating Orders for Local Warehouse: {} ---", localWarehouse.getName());
        // Order the first laptop instance
        if (localWarehouse.addOrder(laptop)) {
            logger.info("Successfully ordered Laptop (ID: {}) from Local Warehouse.", laptop.getId());
        } else {
            logger.warn("Failed to order Laptop (ID: {}) from Local Warehouse.", laptop.getId());
        }

        // Attempt to order the same laptop instance again (should fail as it's removed)
        if (localWarehouse.addOrder(laptop)) {
            logger.info("Successfully ordered Laptop (ID: {}) AGAIN from Local Warehouse.", laptop.getId());
        } else {
            logger.warn("Failed to order Laptop (ID: {}) AGAIN from Local Warehouse (expected: already ordered/removed).", laptop.getId());
        }

        // Order the second distinct laptop instance
        if (localWarehouse.addOrder(anotherLaptop)) {
            logger.info("Successfully ordered Another Laptop (ID: {}) from Local Warehouse.", anotherLaptop.getId());
        } else {
            logger.warn("Failed to order Another Laptop (ID: {}) from Local Warehouse.", anotherLaptop.getId());
        }

        // Order mouse
        if (localWarehouse.addOrder(mouse)) {
            logger.info("Successfully ordered Mouse (ID: {}) from Local Warehouse.", mouse.getId());
        } else {
            logger.warn("Failed to order Mouse (ID: {}) from Local Warehouse.", mouse.getId());
        }

        // 5b. Simulate Orders in Central Warehouse
        logger.info("--- Simulating Orders for Central Warehouse: {} ---", centralWarehouse.getName());
        // Find a gaming mouse to order (since we added them directly)
        Item gamingMouseToOrder = null;
        for(Item stockItem : centralWarehouse.getItems()){
            if(stockItem.getName().equals("Gaming Mouse")){
                gamingMouseToOrder = stockItem;
                break;
            }
        }
        if(gamingMouseToOrder != null){
            if(centralWarehouse.addOrder(gamingMouseToOrder)){
                logger.info("Successfully ordered Gaming Mouse (ID: {}) from Central Warehouse.", gamingMouseToOrder.getId());
            } else {
                 logger.warn("Failed to order Gaming Mouse (ID: {}) from Central Warehouse.", gamingMouseToOrder.getId());
            }
        } else {
            logger.warn("No 'Gaming Mouse' found in Central Warehouse stock to order.");
        }


        // 6. Calculate Total Costs
        logger.info("--- Calculating Total Costs ---");
        double localTotalCost = localWarehouse.calcCost();
        logger.info("Total cost of orders in '{}': ${}", localWarehouse.getName(), String.format("%.2f", localTotalCost));

        double centralTotalCost = centralWarehouse.calcCost();
        logger.info("Total cost of orders in '{}': ${}", centralWarehouse.getName(), String.format("%.2f", centralTotalCost));


        logger.info("--- Final State ---");
        logger.info("Local Warehouse '{}': Stock = {}, Orders = {}", localWarehouse.getName(), localWarehouse.getItems().size(), localWarehouse.getOrders().size());
        localWarehouse.getOrders().forEach(item -> logger.debug("LW Ordered: {}", item));
        logger.info("Central Warehouse '{}': Stock = {}, Orders = {}", centralWarehouse.getName(), centralWarehouse.getItems().size(), centralWarehouse.getOrders().size());
        centralWarehouse.getOrders().forEach(item -> logger.debug("CW Ordered: {}", item));

        logger.info("Warehouse Management System Demonstration Finished.");
    }
}