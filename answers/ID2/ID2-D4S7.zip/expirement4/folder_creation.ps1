# Create the root project folder (if you haven't already)
# For example: mkdir FoodStoreInventory
# cd FoodStoreInventory

# Create the source and binary directories
New-Item -ItemType Directory -Name "src" -Force
New-Item -ItemType Directory -Name "bin" -Force

# Optional: Create package structure within src (if you plan to use packages)
# For this project, we can start simple and put files directly in src,
# or use a base package like 'com.foodstore'. Let's assume a base package for better organization.
New-Item -ItemType Directory -Path "src\com" -Force
New-Item -ItemType Directory -Path "src\com\foodstore" -Force
New-Item -ItemType Directory -Path "src\com\foodstore\products" -Force # For product subclasses
New-Item -ItemType Directory -Path "src\com\foodstore\core" -Force    # For Store and main app

# Output a success message
Write-Host "Project directory structure created successfully:"
Write-Host "  ./src/com/foodstore/core"
Write-Host "  ./src/com/foodstore/products"
Write-Host "  ./bin/"
Write-Host "Place your .java files in the 'src/com/foodstore/...' subdirectories."
Write-Host "Compiled .class files will go into 'bin/'."