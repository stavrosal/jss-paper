```markdown
# Food Store Inventory Management System

## Objective
This project implements an object-oriented system for managing food store inventories using inheritance-based product categorization. The system demonstrates fundamental object-oriented principles including inheritance, encapsulation, and polymorphism.

## System Architecture

### Core Classes:
*   **`Product.java`**: A base class for all products. It includes a `getName()` method and defines equality based on product name via `equals()` and `hashCode()`.
*   **Category Subclasses (inheriting from `Product`):**
    *   **`Vegetable.java`**: Represents vegetable products.
        *   Specialized properties: `isOrganic`, `botanicalFamily`, `typicalGrowingSeason`.
        *   Specialized behavior: `getVegetableSpecificDescription()`.
    *   **`Fruit.java`**: Represents fruit products.
        *   Specialized properties: `isSeedless`, `ripenessIndicator`, `originCountry`.
        *   Specialized behavior: `getConsumerRipenessTip()`.
    *   **`Dairy.java`**: Represents dairy products.
        *   Specialized properties: `fatContentPercentage`, `isLactoseFree`, `storageTemperature`.
        *   Specialized behavior: `getExpirationInfo()`.
*   **`Store.java`**: Manages collections of products.
    *   Stores distinct products using a `java.util.HashSet<Product>`.
    *   Implements `getTotalProductCount()`: Returns the count of distinct product items.
    *   Implements `printAllProductNames()`: Prints the names of all distinct products, sorted alphabetically.

### `Main.java`:
*   A demonstration class that:
    *   Creates a `Store` instance.
    *   Creates instances of `Vegetable`, `Fruit`, and `Dairy` products.
    *   Adds products to the store, demonstrating duplicate handling.
    *   Calls `getTotalProductCount()` and `printAllProductNames()`.
    *   Showcases polymorphism by iterating through the inventory and calling category-specific methods after type checking and downcasting.

## Project Structure

```
FoodStoreInventory/
├── bin/                      # Output directory for compiled .class files
├── src/                      # Source code directory
│   └── com/
│       └── foodstore/
│           ├── core/
│           │   ├── Main.java
│           │   └── Store.java
│           └── products/
│               ├── Dairy.java
│               ├── Fruit.java
│               ├── Product.java
│               └── Vegetable.java
└── folder_creation.ps1       # PowerShell script to create this directory structure
```

## Design Decisions & Inheritance Value

*   **Inheritance:** The `Product` class serves as a base, with `Vegetable`, `Fruit`, and `Dairy` extending it. This creates an "is-a" relationship (e.g., a `Vegetable` is a `Product`). This hierarchy allows for:
    *   **Code Reusability:** Common properties (like `name`) and methods (`getName()`, `equals()`, `hashCode()`) are defined in `Product` and inherited.
    *   **Meaningful Specialization:** Each subclass adds unique attributes (e.g., `isOrganic` for `Vegetable`, `isSeedless` for `Fruit`) and behaviors (e.g., `getVegetableSpecificDescription()`) relevant only to its category. This goes beyond simple tagging and provides true specialized functionality.
    *   **Polymorphism:** The `Store` class can manage a collection of `Product` objects, which can actually be instances of `Vegetable`, `Fruit`, or `Dairy`. This allows for uniform treatment (e.g., adding to inventory, getting name) while still enabling access to specialized features when needed (demonstrated in `Main.java` using `instanceof` and casting).
*   **Encapsulation:** Class members are generally `private`, with `public` getters (and setters where appropriate) to control access to the internal state of objects.
*   **Data Structure for Store:** A `java.util.HashSet<Product>` is used for the store's inventory. This choice directly supports the requirement of managing "distinct product items" because `HashSet` relies on the `equals()` and `hashCode()` methods of `Product` (which define distinctness by name). This makes `getTotalProductCount()` a simple call to `inventory.size()`.

## How to Compile and Run

1.  **Prerequisites:**
    *   Java Development Kit (JDK) installed and configured (e.g., JDK 11 or later).

2.  **Directory Setup:**
    *   Ensure your project files are arranged according to the "Project Structure" section above. You can use the `folder_creation.ps1` script in PowerShell to create the basic `src` and `bin` directories and package structure within `src`.
    *   Place all `.java` files into their respective subdirectories within `src/com/foodstore/`.

3.  **Open a Terminal/Command Prompt:**
    *   Navigate to the root directory of the project (e.g., `FoodStoreInventory/`).

4.  **Compile the Java Files:**
    *   Run the following command:
        ```bash
        javac -d bin -sourcepath src src/com/foodstore/products/*.java src/com/foodstore/core/*.java
        ```
        Alternatively, for PowerShell (if all files are in the correct sub-packages under `src`):
        ```powershell
        javac -d bin -sourcepath src $(Get-ChildItem src -Recurse -Filter *.java | ForEach-Object { $_.FullName })
        ```
        Or for Bash (Linux/macOS):
        ```bash
        javac -d bin -sourcepath src $(find src -name "*.java")
        ```
    *   This command compiles all `.java` files found in the `src` directory (and its subdirectories, respecting package structure) and places the compiled `.class` files into the `bin` directory, also maintaining package structure.

5.  **Run the Application:**
    *   Execute the `Main` class using the following command:
        ```bash
        java -cp bin com.foodstore.core.Main
        ```
    *   `-cp bin` (classpath) tells the Java runtime to look for compiled classes in the `bin` directory.
    *   `com.foodstore.core.Main` is the fully qualified name of the main class to execute.

You should see output in the console demonstrating the system's functionality, including store creation, product additions, product counts, a list of product names, and details from category-specific methods.
```
