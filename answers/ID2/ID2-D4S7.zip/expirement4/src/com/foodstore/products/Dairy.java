// File: src/com/foodstore/products/Dairy.java
package com.foodstore.products;

import java.time.LocalDate; // For a more realistic expiration date, though not fully implemented here

/**
 * Represents a Dairy product in the food store.
 * Extends the base Product class and adds dairy-specific properties
 * such as fat content, lactose-free status, and storage temperature.
 */
public class Dairy extends Product {

    private double fatContentPercentage; // e.g., 3.25 for whole milk, 0.5 for skim
    private boolean isLactoseFree;
    private String storageTemperature;   // e.g., "Refrigerate at 2-4°C"
    // In a real system, expirationDate would likely be per batch, not per product type.
    // For this example, we'll keep it simple or imply it's on the packaging.

    /**
     * Constructs a new Dairy product.
     *
     * @param name The name of the dairy product (e.g., "Milk", "Cheese", "Yogurt").
     * @param fatContentPercentage The fat content in percentage (e.g., 3.25 for 3.25%).
     * @param isLactoseFree True if the product is lactose-free, false otherwise.
     * @param storageTemperature Recommended storage temperature instructions.
     * @throws IllegalArgumentException if name or storageTemperature is null or empty,
     *                                  or if fatContentPercentage is negative.
     */
    public Dairy(String name, double fatContentPercentage, boolean isLactoseFree, String storageTemperature) {
        super(name); // Call the constructor of the base class (Product)
        if (fatContentPercentage < 0) {
            throw new IllegalArgumentException("Fat content percentage cannot be negative.");
        }
        if (storageTemperature == null || storageTemperature.trim().isEmpty()) {
            throw new IllegalArgumentException("Storage temperature instructions cannot be null or empty for a dairy product.");
        }
        this.fatContentPercentage = fatContentPercentage;
        this.isLactoseFree = isLactoseFree;
        this.storageTemperature = storageTemperature;
    }

    /**
     * Gets the fat content percentage of the dairy product.
     *
     * @return The fat content as a double (e.g., 3.25 for 3.25%).
     */
    public double getFatContentPercentage() {
        return fatContentPercentage;
    }

    /**
     * Sets the fat content percentage of the dairy product.
     *
     * @param fatContentPercentage The new fat content. Must not be negative.
     * @throws IllegalArgumentException if fatContentPercentage is negative.
     */
    public void setFatContentPercentage(double fatContentPercentage) {
        if (fatContentPercentage < 0) {
            throw new IllegalArgumentException("Fat content percentage cannot be negative.");
        }
        this.fatContentPercentage = fatContentPercentage;
    }

    /**
     * Checks if the dairy product is lactose-free.
     *
     * @return True if lactose-free, false otherwise.
     */
    public boolean isLactoseFree() {
        return isLactoseFree;
    }

    /**
     * Sets the lactose-free status of the dairy product.
     *
     * @param lactoseFree True if lactose-free, false otherwise.
     */
    public void setLactoseFree(boolean lactoseFree) {
        isLactoseFree = lactoseFree;
    }

    /**
     * Gets the recommended storage temperature for the dairy product.
     *
     * @return A string describing storage temperature (e.g., "Refrigerate at 2-4°C").
     */
    public String getStorageTemperature() {
        return storageTemperature;
    }

    /**
     * Sets the recommended storage temperature for the dairy product.
     *
     * @param storageTemperature The new storage temperature instructions. Cannot be null or empty.
     * @throws IllegalArgumentException if storageTemperature is null or empty.
     */
    public void setStorageTemperature(String storageTemperature) {
        if (storageTemperature == null || storageTemperature.trim().isEmpty()) {
            throw new IllegalArgumentException("Storage temperature instructions cannot be null or empty.");
        }
        this.storageTemperature = storageTemperature;
    }

    /**
     * Provides general information about checking the expiration date for dairy products.
     * In a more complex system, this might involve lot numbers or specific date tracking.
     *
     * @return A general instruction regarding expiration dates.
     */
    public String getExpirationInfo() {
        return "For " + getName() + ", always check the packaging for the 'Use By' or 'Best By' date. " +
               "Store as per instructions: " + storageTemperature + ".";
    }

    /**
     * Returns a string representation of the Dairy product.
     * Overrides the Product.toString() to include dairy-specific details.
     *
     * @return A string representation including name, fat content, and lactose-free status.
     */
    @Override
    public String toString() {
        return super.toString() + " (Dairy) [Fat: " + String.format("%.2f%%", fatContentPercentage) +
               ", Lactose-Free: " + isLactoseFree + ", Storage: " + storageTemperature + "]";
    }

    // As with Vegetable and Fruit, not overriding equals() and hashCode().
    // Product distinctness is based on name. "Whole Milk" and "Skim Milk"
    // would be different products with different names.
}