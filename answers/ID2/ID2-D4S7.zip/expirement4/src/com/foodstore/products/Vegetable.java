// File: src/com/foodstore/products/Vegetable.java
package com.foodstore.products;

/**
 * Represents a Vegetable product in the food store.
 * Extends the base Product class and adds vegetable-specific properties
 * such as organic status and botanical family.
 */
public class Vegetable extends Product {

    private boolean isOrganic;
    private String botanicalFamily; // e.g., "Brassicaceae", "Solanaceae", "Apiaceae"
    private String typicalGrowingSeason; // e.g., "Spring", "Summer", "Autumn", "Winter", "All-Year"

    /**
     * Constructs a new Vegetable product.
     *
     * @param name The name of the vegetable (e.g., "Carrot", "Broccoli").
     * @param isOrganic True if the vegetable is organically grown, false otherwise.
     * @param botanicalFamily The botanical family of the vegetable.
     * @param typicalGrowingSeason The typical season when this vegetable is grown/harvested.
     * @throws IllegalArgumentException if name, botanicalFamily, or typicalGrowingSeason is null or empty.
     */
    public Vegetable(String name, boolean isOrganic, String botanicalFamily, String typicalGrowingSeason) {
        super(name); // Call the constructor of the base class (Product)
        if (botanicalFamily == null || botanicalFamily.trim().isEmpty()) {
            throw new IllegalArgumentException("Botanical family cannot be null or empty for a vegetable.");
        }
        if (typicalGrowingSeason == null || typicalGrowingSeason.trim().isEmpty()) {
            throw new IllegalArgumentException("Typical growing season cannot be null or empty for a vegetable.");
        }
        this.isOrganic = isOrganic;
        this.botanicalFamily = botanicalFamily;
        this.typicalGrowingSeason = typicalGrowingSeason;
    }

    /**
     * Checks if the vegetable is organically grown.
     *
     * @return True if organic, false otherwise.
     */
    public boolean isOrganic() {
        return isOrganic;
    }

    /**
     * Sets the organic status of the vegetable.
     *
     * @param organic True if organic, false otherwise.
     */
    public void setOrganic(boolean organic) {
        isOrganic = organic;
    }

    /**
     * Gets the botanical family of the vegetable.
     *
     * @return The botanical family (e.g., "Brassicaceae").
     */
    public String getBotanicalFamily() {
        return botanicalFamily;
    }

    /**
     * Sets the botanical family of the vegetable.
     *
     * @param botanicalFamily The new botanical family. Cannot be null or empty.
     * @throws IllegalArgumentException if botanicalFamily is null or empty.
     */
    public void setBotanicalFamily(String botanicalFamily) {
        if (botanicalFamily == null || botanicalFamily.trim().isEmpty()) {
            throw new IllegalArgumentException("Botanical family cannot be null or empty.");
        }
        this.botanicalFamily = botanicalFamily;
    }

    /**
     * Gets the typical growing season for this vegetable.
     *
     * @return A string representing the growing season (e.g., "Summer", "All-Year").
     */
    public String getTypicalGrowingSeason() {
        return typicalGrowingSeason;
    }

    /**
     * Sets the typical growing season for this vegetable.
     *
     * @param typicalGrowingSeason The new growing season. Cannot be null or empty.
     * @throws IllegalArgumentException if typicalGrowingSeason is null or empty.
     */
    public void setTypicalGrowingSeason(String typicalGrowingSeason) {
        if (typicalGrowingSeason == null || typicalGrowingSeason.trim().isEmpty()) {
            throw new IllegalArgumentException("Typical growing season cannot be null or empty.");
        }
        this.typicalGrowingSeason = typicalGrowingSeason;
    }

    /**
     * Provides a more detailed description specific to vegetables.
     * This demonstrates a category-specific behavior.
     *
     * @return A string describing the vegetable's characteristics.
     */
    public String getVegetableSpecificDescription() {
        return getName() + " is a " + (isOrganic ? "organic" : "conventional") +
               " vegetable from the " + botanicalFamily + " family, typically available in " + typicalGrowingSeason + ".";
    }

    /**
     * Returns a string representation of the Vegetable.
     * Overrides the Product.toString() to include vegetable-specific details.
     *
     * @return A string representation including name, organic status, and botanical family.
     */
    @Override
    public String toString() {
        return super.toString() + " (Vegetable) [Organic: " + isOrganic +
               ", Family: " + botanicalFamily + ", Season: " + typicalGrowingSeason + "]";
    }

    // No need to override equals() and hashCode() if the identity of a Vegetable
    // as a "distinct product item" is solely determined by its name (inherited from Product).
    // If "Organic Carrot" and "Conventional Carrot" are considered different *product entries*
    // in the store, they should have different names, e.g., "Carrot, Organic" and "Carrot, Conventional".
    // If they have the same name "Carrot", then isOrganic is just an attribute of that single product entry.
    // The prompt implies distinctness by product item (name), not by attributes of items with the same name.
}