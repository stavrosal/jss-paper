// File: src/com/foodstore/products/Fruit.java
package com.foodstore.products;

/**
 * Represents a Fruit product in the food store.
 * Extends the base Product class and adds fruit-specific properties
 * such as seedless status, ripeness indicators, and country of origin.
 */
public class Fruit extends Product {

    private boolean isSeedless;
    private String ripenessIndicator; // e.g., "Soft to touch", "Changes color", "Fragrant"
    private String originCountry;

    /**
     * Constructs a new Fruit product.
     *
     * @param name The name of the fruit (e.g., "Apple", "Banana").
     * @param isSeedless True if the fruit is a seedless variety, false otherwise.
     * @param ripenessIndicator A description of how to determine ripeness.
     * @param originCountry The country where the fruit was grown.
     * @throws IllegalArgumentException if name, ripenessIndicator, or originCountry is null or empty.
     */
    public Fruit(String name, boolean isSeedless, String ripenessIndicator, String originCountry) {
        super(name); // Call the constructor of the base class (Product)
        if (ripenessIndicator == null || ripenessIndicator.trim().isEmpty()) {
            throw new IllegalArgumentException("Ripeness indicator cannot be null or empty for a fruit.");
        }
        if (originCountry == null || originCountry.trim().isEmpty()) {
            throw new IllegalArgumentException("Origin country cannot be null or empty for a fruit.");
        }
        this.isSeedless = isSeedless;
        this.ripenessIndicator = ripenessIndicator;
        this.originCountry = originCountry;
    }

    /**
     * Checks if the fruit is a seedless variety.
     *
     * @return True if seedless, false otherwise.
     */
    public boolean isSeedless() {
        return isSeedless;
    }

    /**
     * Sets the seedless status of the fruit.
     *
     * @param seedless True if seedless, false otherwise.
     */
    public void setSeedless(boolean seedless) {
        isSeedless = seedless;
    }

    /**
     * Gets the ripeness indicator for the fruit.
     *
     * @return A string describing how to check for ripeness.
     */
    public String getRipenessIndicator() {
        return ripenessIndicator;
    }

    /**
     * Sets the ripeness indicator for the fruit.
     *
     * @param ripenessIndicator The new ripeness indicator. Cannot be null or empty.
     * @throws IllegalArgumentException if ripenessIndicator is null or empty.
     */
    public void setRipenessIndicator(String ripenessIndicator) {
        if (ripenessIndicator == null || ripenessIndicator.trim().isEmpty()) {
            throw new IllegalArgumentException("Ripeness indicator cannot be null or empty.");
        }
        this.ripenessIndicator = ripenessIndicator;
    }

    /**
     * Gets the country of origin for the fruit.
     *
     * @return The country of origin.
     */
    public String getOriginCountry() {
        return originCountry;
    }

    /**
     * Sets the country of origin for the fruit.
     *
     * @param originCountry The new country of origin. Cannot be null or empty.
     * @throws IllegalArgumentException if originCountry is null or empty.
     */
    public void setOriginCountry(String originCountry) {
        if (originCountry == null || originCountry.trim().isEmpty()) {
            throw new IllegalArgumentException("Origin country cannot be null or empty.");
        }
        this.originCountry = originCountry;
    }

    /**
     * Provides a consumer tip specific to fruits, related to ripeness.
     * This demonstrates a category-specific behavior.
     *
     * @return A string with a tip for the consumer.
     */
    public String getConsumerRipenessTip() {
        return "For " + getName() + " from " + originCountry +
               ", check for ripeness by looking for: '" + ripenessIndicator + "'. " +
               (isSeedless ? "This variety is seedless." : "This variety contains seeds.");
    }

    /**
     * Returns a string representation of the Fruit.
     * Overrides the Product.toString() to include fruit-specific details.
     *
     * @return A string representation including name, seedless status, and origin.
     */
    @Override
    public String toString() {
        return super.toString() + " (Fruit) [Seedless: " + isSeedless +
               ", Ripeness: '" + ripenessIndicator + "', Origin: " + originCountry + "]";
    }

    // Again, not overriding equals() and hashCode() as product distinctness
    // is assumed to be based on name, inherited from Product.
    // If "Seedless Grapes" and "Seeded Grapes" are different product items,
    // they should have different names.
}