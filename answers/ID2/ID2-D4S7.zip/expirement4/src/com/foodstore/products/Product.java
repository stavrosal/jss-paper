// File: src/com/foodstore/products/Product.java
package com.foodstore.products;

/**
 * Base class for all products in the food store.
 * Provides a common interface for getting the product's name.
 * This class is intended to be extended by specific product categories.
 */
public class Product {
    private String name;

    /**
     * Constructs a new Product with the given name.
     *
     * @param name The name of the product. Cannot be null or empty.
     * @throws IllegalArgumentException if the name is null or empty.
     */
    public Product(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Product name cannot be null or empty.");
        }
        this.name = name;
    }

    /**
     * Gets the name of the product.
     *
     * @return The name of the product.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns a string representation of the Product, which is its name.
     * This can be useful for debugging or simple display.
     *
     * @return The name of the product.
     */
    @Override
    public String toString() {
        return name; // Simple representation, often useful.
    }

    /**
     * Indicates whether some other object is "equal to" this one.
     * Products are considered equal if they have the same name (case-sensitive).
     * This is important for managing distinct products in the Store.
     *
     * @param obj The reference object with which to compare.
     * @return {@code true} if this object is the same as the obj argument;
     *         {@code false} otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Product product = (Product) obj;
        return name.equals(product.name);
    }

    /**
     * Returns a hash code value for the object.
     * This method is supported for the benefit of hash tables such as those provided by {@link java.util.HashMap}.
     * Consistent with equals(), if two products are equal, they must have the same hash code.
     *
     * @return A hash code value for this object.
     */
    @Override
    public int hashCode() {
        return name.hashCode();
    }
}