// File: src/com/foodstore/core/Main.java
package com.foodstore.core;

import com.foodstore.products.Dairy;
import com.foodstore.products.Fruit;
import com.foodstore.products.Product;
import com.foodstore.products.Vegetable;

/**
 * Main application class to demonstrate the Food Store Inventory Management System.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("=== Food Store Inventory Management System Demo ===");

        // 1. Create a Store
        Store myFoodStore = new Store("Bob's Fresh Mart");
        System.out.println("\n--- Initializing Store: " + myFoodStore.getStoreName() + " ---");

        // 2. Create instances of various products
        System.out.println("\n--- Creating Products ---");
        Product apple = new Fruit("Apple", false, "Firm to touch, vibrant color", "USA");
        Product banana = new Fruit("Banana", false, "Yellow with few brown spots", "Ecuador");
        Product seedlessGrapes = new Fruit("Seedless Grapes", true, "Plump and firmly attached to stem", "Chile");

        Product carrot = new Vegetable("Carrot", true, "Apiaceae", "Spring/Autumn");
        Product broccoli = new Vegetable("Broccoli", false, "Brassicaceae", "Cool Seasons");
        Product spinach = new Vegetable("Spinach", true, "Amaranthaceae", "Spring/Autumn");

        Product milk = new Dairy("Whole Milk", 3.25, false, "Refrigerate at 2-4°C");
        Product cheese = new Dairy("Cheddar Cheese", 33.0, false, "Refrigerate at 2-7°C");
        Product yogurt = new Dairy("Greek Yogurt", 10.0, false, "Refrigerate at 1-4°C");
        Product lactoseFreeMilk = new Dairy("Lactose-Free Milk", 2.0, true, "Refrigerate at 2-4°C");

        // 3. Add products to the store
        System.out.println("\n--- Adding Products to Store ---");
        myFoodStore.addProduct(apple);
        myFoodStore.addProduct(banana);
        myFoodStore.addProduct(seedlessGrapes);
        myFoodStore.addProduct(carrot);
        myFoodStore.addProduct(broccoli);
        myFoodStore.addProduct(spinach);
        myFoodStore.addProduct(milk);
        myFoodStore.addProduct(cheese);
        myFoodStore.addProduct(yogurt);
        myFoodStore.addProduct(lactoseFreeMilk);

        // Attempting to add a duplicate product (should be ignored by the Set)
        System.out.println("\n--- Attempting to Add Duplicate Product ---");
        Product anotherApple = new Fruit("Apple", false, "Crisp", "Canada"); // Same name as existing 'apple'
        myFoodStore.addProduct(anotherApple); // This should not increase the distinct product count

        // 4. Demonstrate getTotalProductCount()
        System.out.println("\n--- Inventory Count ---");
        System.out.println("Total distinct products in " + myFoodStore.getStoreName() + ": " + myFoodStore.getTotalProductCount());

        // 5. Demonstrate printAllProductNames()
        myFoodStore.printAllProductNames();

        // 6. Demonstrate polymorphism and category-specific methods
        System.out.println("\n--- Demonstrating Category-Specific Features (Polymorphism) ---");
        for (Product p : myFoodStore.getInventoryView()) { // Using the unmodifiable view
            System.out.print("Product: " + p.getName());
            if (p instanceof Vegetable) {
                Vegetable veg = (Vegetable) p; // Downcasting
                System.out.print(" (Vegetable) - Organic: " + veg.isOrganic() + ", Season: " + veg.getTypicalGrowingSeason());
                System.out.println("\n   -> Specifics: " + veg.getVegetableSpecificDescription());
            } else if (p instanceof Fruit) {
                Fruit fruit = (Fruit) p; // Downcasting
                System.out.print(" (Fruit) - Seedless: " + fruit.isSeedless() + ", Origin: " + fruit.getOriginCountry());
                System.out.println("\n   -> Tip: " + fruit.getConsumerRipenessTip());
            } else if (p instanceof Dairy) {
                Dairy dairy = (Dairy) p; // Downcasting
                System.out.print(" (Dairy) - Fat: " + dairy.getFatContentPercentage() + "%, Lactose-Free: " + dairy.isLactoseFree());
                System.out.println("\n   -> Storage/Expiry: " + dairy.getExpirationInfo());
            } else {
                // Should not happen with our current product types
                System.out.print(" (Generic Product)");
            }
            System.out.println(); // Extra newline for readability
        }

        // Demonstrate removing a product
        System.out.println("\n--- Demonstrating Product Removal ---");
        Product productToRemove = new Product("Banana"); // Create a product object that would be equal to the one in store
        if (myFoodStore.hasProduct(productToRemove)) {
            myFoodStore.removeProduct(productToRemove);
            System.out.println("Successfully removed '" + productToRemove.getName() + "'.");
        } else {
            System.out.println("Could not find '" + productToRemove.getName() + "' to remove.");
        }
        System.out.println("Total distinct products after removal: " + myFoodStore.getTotalProductCount());
        myFoodStore.printAllProductNames();


        System.out.println("\n=== Demo Complete ===");
    }
}