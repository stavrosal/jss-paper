// File: src/com/foodstore/core/Store.java
package com.foodstore.core;

import com.foodstore.products.Product;
import java.util.Set;
import java.util.HashSet;
import java.util.Collections;
import java.util.ArrayList; // For sorting before printing, if desired
import java.util.Comparator; // For sorting by name

/**
 * Manages a collection of distinct products for a food store.
 * Uses a Set to ensure that only unique product items (based on their name) are stored.
 */
public class Store {
    private final String storeName;
    private final Set<Product> inventory;

    /**
     * Constructs a new Store with a given name.
     * Initializes an empty inventory to hold products.
     *
     * @param storeName The name of the store. Cannot be null or empty.
     * @throws IllegalArgumentException if storeName is null or empty.
     */
    public Store(String storeName) {
        if (storeName == null || storeName.trim().isEmpty()) {
            throw new IllegalArgumentException("Store name cannot be null or empty.");
        }
        this.storeName = storeName;
        this.inventory = new HashSet<>();
        System.out.println("Store '" + storeName + "' created and open for business!");
    }

    /**
     * Adds a product to the store's inventory.
     * If a product with the same name already exists, it will not be added.
     *
     * @param product The product to add. Cannot be null.
     * @return true if the product was added, false otherwise.
     * @throws IllegalArgumentException if the product is null.
     */
    public boolean addProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Cannot add a null product to the store.");
        }
        boolean added = this.inventory.add(product);
        if (added) {
            // System.out.println("Product added to " + this.storeName + ": " + product.getName()); // Less verbose for bulk adds
        } else {
            // System.out.println("Product '" + product.getName() + "' already exists in " + this.storeName + "'s inventory. Not added again.");
        }
        return added;
    }

    /**
     * Gets the name of the store.
     *
     * @return The store's name.
     */
    public String getStoreName() {
        return storeName;
    }

    // --- REQUIRED METHODS ---

    /**
     * Returns the total number of distinct product items currently in the store's inventory.
     * This is not the quantity of units, but the count of different product types.
     *
     * @return The total count of distinct products.
     */
    public int getTotalProductCount() {
        return this.inventory.size(); // The size of the HashSet directly gives the count of distinct items
    }

    /**
     * Prints the names of all products in the store to standard output,
     * one name per line, using each product's getName() method.
     * The products are printed in alphabetical order by name.
     */
    public void printAllProductNames() {
        System.out.println("\n--- Product Listing for '" + this.storeName + "' ---");
        if (this.inventory.isEmpty()) {
            System.out.println("The inventory is currently empty.");
            return;
        }

        // To print in a defined order (e.g., alphabetical by name),
        // we copy to a List and sort it.
        ArrayList<Product> sortedProducts = new ArrayList<>(this.inventory);
        sortedProducts.sort(Comparator.comparing(Product::getName)); // Sort by product name

        for (Product product : sortedProducts) {
            System.out.println(product.getName());
        }
        System.out.println("--------------------------------------");
    }

    // --- Optional methods (good for completeness, but not strictly required by prompt) ---

    /**
     * Removes a product from the store's inventory.
     *
     * @param product The product to remove. Cannot be null.
     * @return true if the product was found and removed, false otherwise.
     * @throws IllegalArgumentException if the product is null.
     */
    public boolean removeProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Cannot remove a null product.");
        }
        boolean removed = this.inventory.remove(product);
        if (removed) {
            // System.out.println("Product removed from " + this.storeName + ": " + product.getName());
        } else {
            // System.out.println("Product '" + product.getName() + "' not found in " + this.storeName + "'s inventory for removal.");
        }
        return removed;
    }

    /**
     * Checks if a specific product is currently in the inventory.
     *
     * @param product The product to check for.
     * @return true if the product is in inventory, false otherwise.
     */
    public boolean hasProduct(Product product) {
        if (product == null) {
            return false;
        }
        return this.inventory.contains(product);
    }

    /**
     * Provides a read-only view of the inventory.
     *
     * @return An unmodifiable Set of products in the inventory.
     */
    public Set<Product> getInventoryView() {
        return Collections.unmodifiableSet(this.inventory);
    }
}