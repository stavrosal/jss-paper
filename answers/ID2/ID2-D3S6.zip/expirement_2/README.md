This project implements a system for managing multiple Finite State Machines (FSMs), each performing specific computational tasks with a consistent lifecycle. It's designed for scenarios like batch processing where different computation types need uniform management and monitoring. This implementation adheres to the "Bob-Code Principles & Style" for clarity, robustness, and maintainability.

The core of the system is the `FiniteStateMachine` interface, which all FSMs must implement. Each machine follows a standard lifecycle: Construction, Running, Finished, and Completion.

## Project Structure

The project is organized as follows:

```
fsm_system_project/
├── src/                      # Source code
│   └── com/
│       └── myfsmsystem/      # Base package
│           ├── App.java      # Main application for demonstration
│           ├── core/         # Core FSM interfaces and enums
│           │   ├── FiniteStateMachine.java
│           │   └── MachineState.java
│           └── machines/     # Specific FSM implementations
│               ├── DivisibleNumbersMachine.java
│               └── PushDownAutomaton.java
├── bin/                      # Compiled .class files (generated)
├── doc/                      # Javadoc HTML documentation (generated)
└── README.md                 # This file
```

## Implemented Machines

1.  **`DivisibleNumbersMachine`**
    *   **Purpose:** Finds all numbers divisible by 4 up to a specified threshold.
    *   **Result:** `List<Integer>` of divisible numbers.
    *   **Processing:** Computation (checking numbers) occurs incrementally with each call to `isFinished()` when the machine is in the `RUNNING` state.

2.  **`PushDownAutomaton`**
    *   **Purpose:** Calculates the sum of numbers from 1 up to a specified threshold using a stack-like behavior (implemented with `ArrayList`).
    *   **Result:** `Integer` representing the sum.
    *   **Processing:** Numbers are pushed onto the internal stack incrementally with each call to `isFinished()`. The sum is calculated during the `finish()` phase by popping all numbers from the stack.

## Building the Project (Plain Java)

No external build tools like Maven or Gradle are required for this basic setup.

1.  **Prerequisites:**
    *   Java Development Kit (JDK) installed (e.g., JDK 11 or later).
    *   `javac` (compiler) and `java` (runtime) commands available in your system's PATH.

2.  **Compilation:**
    Open a terminal or PowerShell, navigate to the root directory (`fsm_system_project`), and run:
    ```bash
    javac -d bin src/com/myfsmsystem/core/FiniteStateMachine.java src/com/myfsmsystem/core/MachineState.java src/com/myfsmsystem/machines/DivisibleNumbersMachine.java src/com/myfsmsystem/machines/PushDownAutomaton.java src/com/myfsmsystem/App.java
    ```
    This command compiles all source files and places the `.class` files into the `bin` directory, maintaining the package structure.

## Running the Demonstration

After successful compilation:

1.  Navigate to the root project directory (`fsm_system_project`) in your terminal.
2.  Execute the main application:
    ```bash
    java -cp bin com.myfsmsystem.App
    ```
    This will run the `main` method in `App.java`, demonstrating the lifecycle and output of both implemented FSMs.

## Viewing Javadoc

To generate and view the API documentation:

1.  Navigate to the root project directory.
2.  Run the `javadoc` command:
    ```bash
    javadoc -d doc -sourcepath src -subpackages com.myfsmsystem
    ```
3.  Open `fsm_system_project/doc/index.html` in a web browser.

## Design Choices & Notes

*   **Incremental Processing:** The `isFinished()` method in both FSM implementations is designed to perform a unit of work. This simulates the "machine processes automatically" behavior when `isFinished()` is polled in a loop.
*   **State Management:** The `MachineState` enum (`INITIALIZED`, `RUNNING`, `FINISHED`) is used for clear and robust state tracking.
*   **Error Handling:** Methods enforce correct lifecycle progression by throwing `IllegalStateException` for invalid operations (e.g., calling `getResult()` before `finish()`). Constructor arguments are validated (e.g., positive threshold).
*   **Immutability of Results:** `DivisibleNumbersMachine` returns an unmodifiable list via `Collections.unmodifiableList()` to protect its internal state.
*   **Generics:** The `FiniteStateMachine<T>` interface uses generics for `getResult()` to provide type safety for machine results.

## System Extensibility

To add a new FSM type:
1.  Create a new Java class in the `com.myfsmsystem.machines` package (or a new sub-package).
2.  Implement the `com.myfsmsystem.core.FiniteStateMachine<T>` interface, specifying the result type `T`.
3.  Implement all required methods (`start`, `isFinished`, `finish`, `getResult`) according to the new machine's logic and the FSM lifecycle.
4.  The new machine can then be instantiated and managed like the existing ones.

## Thread Safety Considerations

The current FSM implementations (`DivisibleNumbersMachine`, `PushDownAutomaton`) are **not inherently thread-safe** if a single instance's methods (`start`, `isFinished`, `finish`) are called concurrently by multiple threads. They manage internal state (e.g., `currentState`, result collections, counters) that would be subject to race conditions.

**Recommended Usage in Concurrent Environments:**

1.  **Single-Threaded Access per Instance:** The safest way to use these FSM instances in a multi-threaded application is to ensure that each FSM instance is only accessed and driven through its lifecycle by a single thread at any given time. A pool of worker threads could each pick up an FSM task and process it exclusively.
2.  **External Synchronization:** If multiple threads *must* interact with the same FSM instance, external synchronization mechanisms (e.g., `synchronized` blocks around FSM method calls, or using `java.util.concurrent.locks.Lock`) would be required by the calling code.
3.  **Internal Synchronization (More Complex):** Alternatively, the FSM implementations themselves could be modified to include internal synchronization (e.g., making methods `synchronized` or using concurrent data structures and locks). This adds complexity to the FSM design and should be done carefully to avoid deadlocks and performance bottlenecks.

For this project's scope, the FSMs are designed assuming single-threaded interaction per instance, which is common for batch processing tasks where each task (FSM) is handled independently.
```
