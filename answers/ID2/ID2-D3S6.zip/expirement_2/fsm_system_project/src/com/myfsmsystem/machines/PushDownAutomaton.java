package com.myfsmsystem.machines;

import com.myfsmsystem.core.FiniteStateMachine;
import com.myfsmsystem.core.MachineState;

import java.util.ArrayList; // To be used as a stack

/**
 * A Finite State Machine that calculates the sum of numbers from 1 up to a
 * specified threshold using a stack-like behavior with an ArrayList.
 *
 * Numbers from 1 to threshold are pushed onto the "stack" during the processing
 * phase (driven by calls to {@link #isFinished()}). The final sum is computed
 * by popping all elements from the stack during the {@link #finish()} phase.
 */
public class PushDownAutomaton implements FiniteStateMachine<Integer> {

    private final int threshold;
    private ArrayList<Integer> stack; // Using ArrayList as a stack
    private MachineState currentState;
    private int sumResult;
    private int numbersPushedToStack; // Tracks how many numbers have been pushed

    /**
     * Constructs a PushDownAutomaton with a specified upper limit (threshold).
     *
     * @param threshold The upper limit for the numbers to be summed (inclusive).
     *                  Numbers from 1 to threshold will be processed.
     *                  Must be a positive integer.
     * @throws IllegalArgumentException if the threshold is not positive.
     */
    public PushDownAutomaton(int threshold) {
        if (threshold <= 0) {
            // System.err.println("ERROR: PushDownAutomaton - Threshold must be positive. Received: " + threshold);
            throw new IllegalArgumentException("Threshold must be positive. Received: " + threshold);
        }
        this.threshold = threshold;
        this.stack = new ArrayList<>();
        this.currentState = MachineState.INITIALIZED;
        this.sumResult = 0;
        this.numbersPushedToStack = 0;
        // System.out.println("INFO: PushDownAutomaton created with threshold: " + threshold + ". State: " + this.currentState);
    }

    /**
     * {@inheritDoc}
     * Transitions the machine to the RUNNING state and prepares the stack.
     * Resets any previous state if the machine is re-started.
     */
    @Override
    public void start() {
        // System.out.println("INFO: PushDownAutomaton - start() called. Current state: " + this.currentState);
        if (this.currentState == MachineState.RUNNING) {
            // System.err.println("ERROR: PushDownAutomaton - Machine is already running.");
            throw new IllegalStateException("Machine is already running. Finish or reset first.");
        }

        this.stack.clear();
        this.sumResult = 0;
        this.numbersPushedToStack = 0;
        this.currentState = MachineState.RUNNING;
        // System.out.println("INFO: PushDownAutomaton started. State: " + this.currentState);
    }

    /**
     * {@inheritDoc}
     * Checks if all numbers from 1 up to the threshold have been pushed onto the stack.
     * Each call to this method (while in the RUNNING state and not yet finished)
     * pushes the next number onto the stack.
     *
     * @return {@code true} if all numbers up to the threshold have been pushed,
     *         {@code false} otherwise.
     */
    @Override
    public boolean isFinished() {
        // System.out.println("DEBUG: PushDownAutomaton - isFinished() called. State: " + this.currentState + ", Pushed: " + this.numbersPushedToStack);
        if (this.currentState == MachineState.INITIALIZED) {
            // System.out.println("DEBUG: PushDownAutomaton - isFinished: false (INITIALIZED).");
            return false; // Not started yet
        }
        if (this.currentState == MachineState.FINISHED) {
            // System.out.println("DEBUG: PushDownAutomaton - isFinished: true (already FINISHED).");
            return true; // Already finished
        }

        // If running, perform a step of computation (pushing to stack)
        if (this.currentState == MachineState.RUNNING) {
            if (this.numbersPushedToStack < this.threshold) {
                this.numbersPushedToStack++;
                this.stack.add(this.numbersPushedToStack); // Push current number
                // System.out.println("DEBUG: PushDownAutomaton - Pushed to stack: " + this.numbersPushedToStack);
                // System.out.println("DEBUG: PushDownAutomaton - isFinished: false (RUNNING, pushed " + this.numbersPushedToStack + "/" + this.threshold + ").");
                return false; // Still processing (pushing)
            } else {
                // All numbers up to threshold have been pushed to stack
                // System.out.println("INFO: PushDownAutomaton - All numbers pushed to stack.");
                return true;
            }
        }
        return false; // Should not be reached
    }

    /**
     * {@inheritDoc}
     * Computes the final sum by popping all numbers from the stack and adding them.
     * Transitions the machine to the FINISHED state.
     * This method should be called after {@link #isFinished()} returns true.
     */
    @Override
    public void finish() {
        // System.out.println("INFO: PushDownAutomaton - finish() called. Current state: " + this.currentState);
        if (this.currentState == MachineState.INITIALIZED) {
            // System.err.println("ERROR: PushDownAutomaton - Cannot finish an unstarted machine.");
            throw new IllegalStateException("Machine has not been started yet.");
        }
        // Ensure all numbers are pushed, or rely on isFinished() having returned true.
        // A stricter check: if (this.currentState == MachineState.RUNNING && this.numbersPushedToStack < this.threshold)
        // throw new IllegalStateException("Not all numbers pushed to stack, cannot finish.");

        this.sumResult = 0;
        // Pop all elements from stack and sum them up
        while (!this.stack.isEmpty()) {
            // To simulate stack pop: remove from the end of the ArrayList
            this.sumResult += this.stack.remove(this.stack.size() - 1);
        }
        // System.out.println("INFO: PushDownAutomaton - Sum computed: " + this.sumResult);

        this.currentState = MachineState.FINISHED;
        // System.out.println("INFO: PushDownAutomaton finished. State: " + this.currentState);
    }

    /**
     * {@inheritDoc}
     * Returns the computed sum of numbers from 1 to the threshold.
     *
     * @return The computed sum as an Integer.
     * @throws IllegalStateException if the machine is not in the FINISHED state.
     */
    @Override
    public Integer getResult() {
        // System.out.println("INFO: PushDownAutomaton - getResult() called. Current state: " + this.currentState);
        if (this.currentState != MachineState.FINISHED) {
            // System.err.println("ERROR: PushDownAutomaton - Cannot get result, machine not in FINISHED state. Current state: " + this.currentState);
            throw new IllegalStateException("Machine is not in FINISHED state. Call start(), wait for isFinished() to be true, then call finish().");
        }
        return this.sumResult;
    }
}