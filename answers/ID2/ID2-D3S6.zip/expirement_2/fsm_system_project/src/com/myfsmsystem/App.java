package com.myfsmsystem; // Base package for the application entry point

import com.myfsmsystem.core.FiniteStateMachine;
import com.myfsmsystem.machines.DivisibleNumbersMachine;
import com.myfsmsystem.machines.PushDownAutomaton;

import java.util.List;

/**
 * Main application class to demonstrate the usage of various Finite State Machines.
 * This class follows the example usage patterns provided in the FSM system specification.
 */
public class App {

    public static void main(String[] args) {
        System.out.println("===== FSM System Demo Start =====");
        System.out.println();

        // --- Test DivisibleNumbersMachine ---
        System.out.println("--- Testing DivisibleNumbersMachine ---");
        int divThreshold = 20; // Using a smaller threshold for concise output
        System.out.println("Initializing DivisibleNumbersMachine with threshold: " + divThreshold);
        FiniteStateMachine<List<Integer>> divMachine = new DivisibleNumbersMachine(divThreshold);

        System.out.println("Starting DivisibleNumbersMachine...");
        divMachine.start();

        System.out.println("Processing DivisibleNumbersMachine (polling isFinished)...");
        int pollCountDiv = 0;
        while (!divMachine.isFinished()) {
            pollCountDiv++;
            // In a real application, other work might be done here,
            // or a small delay might be introduced if FSMs were truly asynchronous.
            // For our current synchronous FSMs where isFinished() does work,
            // this loop drives the computation.
            if (pollCountDiv % 5 == 0 && pollCountDiv <= divThreshold) { // Log progress occasionally
                 System.out.println("  DivisibleNumbersMachine: Polled " + pollCountDiv + " times, still processing...");
            }
        }
        System.out.println("DivisibleNumbersMachine processing complete after " + pollCountDiv + " relevant polls.");

        System.out.println("Finishing DivisibleNumbersMachine...");
        divMachine.finish();

        System.out.println("Getting result from DivisibleNumbersMachine...");
        List<Integer> divisibleNumbers = divMachine.getResult();
        System.out.println("Numbers divisible by 4 up to " + divThreshold + ": " + divisibleNumbers);
        System.out.println("------------------------------------");
        System.out.println();


        // --- Test PushDownAutomaton ---
        System.out.println("--- Testing PushDownAutomaton ---");
        int pdaThreshold = 10; // Using a smaller threshold for concise output
        System.out.println("Initializing PushDownAutomaton with threshold: " + pdaThreshold);
        FiniteStateMachine<Integer> pdaMachine = new PushDownAutomaton(pdaThreshold);

        System.out.println("Starting PushDownAutomaton...");
        pdaMachine.start();

        System.out.println("Processing PushDownAutomaton (polling isFinished)...");
        int pollCountPda = 0;
        while (!pdaMachine.isFinished()) {
            pollCountPda++;
            // This loop drives the number-pushing process.
            if (pollCountPda <= pdaThreshold) { // Log progress for each number pushed
                 System.out.println("  PushDownAutomaton: Polled " + pollCountPda + " times (pushed " + pollCountPda + "), still processing...");
            }
        }
        System.out.println("PushDownAutomaton processing (pushing) complete after " + pollCountPda + " relevant polls.");

        System.out.println("Finishing PushDownAutomaton (computing sum)...");
        pdaMachine.finish();

        System.out.println("Getting result from PushDownAutomaton...");
        Integer sum = pdaMachine.getResult();
        System.out.println("Sum of numbers from 1 to " + pdaThreshold + ": " + sum);
        // For verification: sum of 1 to N = N*(N+1)/2. For N=10, sum = 10*11/2 = 55.
        System.out.println("Expected sum for threshold " + pdaThreshold + ": " + (pdaThreshold * (pdaThreshold + 1) / 2));
        System.out.println("------------------------------------");
        System.out.println();

        // --- Test Edge Cases / Invalid Operations (Optional but good for demonstration) ---
        System.out.println("--- Testing Invalid Operations (Expect Exceptions) ---");
        try {
            System.out.println("Attempting to getResult() from DivisibleNumbersMachine before finish()...");
            FiniteStateMachine<List<Integer>> invalidDivMachine = new DivisibleNumbersMachine(5);
            invalidDivMachine.start();
            while(!invalidDivMachine.isFinished()){ /* process */ }
            // Missing finish() call
            invalidDivMachine.getResult(); // Should throw IllegalStateException
        } catch (IllegalStateException e) {
            System.out.println("  CAUGHT EXPECTED EXCEPTION: " + e.getMessage());
        }

        try {
            System.out.println("Attempting to start() an already running machine (PushDownAutomaton)...");
            FiniteStateMachine<Integer> pdaMachine2 = new PushDownAutomaton(3);
            pdaMachine2.start();
            pdaMachine2.start(); // Should throw IllegalStateException
        } catch (IllegalStateException e) {
            System.out.println("  CAUGHT EXPECTED EXCEPTION: " + e.getMessage());
        }
         System.out.println("------------------------------------");
        System.out.println();

        System.out.println("===== FSM System Demo End =====");
    }
}