package com.myfsmsystem.machines;

import com.myfsmsystem.core.FiniteStateMachine;
import com.myfsmsystem.core.MachineState;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A Finite State Machine that finds all numbers divisible by 4 up to a specified threshold.
 *
 * This machine implements the {@link FiniteStateMachine} interface and follows the
 * standard FSM lifecycle: INITIALIZED -> RUNNING -> FINISHED.
 *
 * The computation (finding divisible numbers) is performed incrementally when
 * the {@link #isFinished()} method is called, simulating a machine that
 * "processes automatically" when polled.
 */
public class DivisibleNumbersMachine implements FiniteStateMachine<List<Integer>> {

    private final int threshold;
    private List<Integer> divisibleNumbers;
    private MachineState currentState;
    private int currentNumberProcessed; // Tracks the number currently being checked

    /**
     * Constructs a DivisibleNumbersMachine with a specified upper limit (threshold).
     *
     * @param threshold The upper limit (exclusive, e.g., if 100, processes 1 to 99)
     *                  for finding numbers divisible by 4. Must be a positive integer.
     *                  If threshold is N, numbers from 1 up to N will be checked.
     * @throws IllegalArgumentException if the threshold is not positive.
     */
    public DivisibleNumbersMachine(int threshold) {
        if (threshold <= 0) {
            // System.err.println("ERROR: DivisibleNumbersMachine - Threshold must be positive. Received: " + threshold);
            throw new IllegalArgumentException("Threshold must be positive. Received: " + threshold);
        }
        this.threshold = threshold;
        this.divisibleNumbers = new ArrayList<>();
        this.currentState = MachineState.INITIALIZED;
        this.currentNumberProcessed = 0; // Start checking from 1
        // System.out.println("INFO: DivisibleNumbersMachine created with threshold: " + threshold + ". State: " + this.currentState);
    }

    /**
     * {@inheritDoc}
     * Transitions the machine to the RUNNING state and prepares for computation.
     * Resets any previous results if the machine is re-started.
     */
    @Override
    public void start() {
        // System.out.println("INFO: DivisibleNumbersMachine - start() called. Current state: " + this.currentState);
        if (this.currentState == MachineState.RUNNING) {
            // System.err.println("ERROR: DivisibleNumbersMachine - Machine is already running.");
            // Optionally, allow restart by resetting, or throw exception.
            // For now, let's make it strict.
            throw new IllegalStateException("Machine is already running. Finish or reset first.");
        }
        // If re-starting from a FINISHED state, allow it by resetting.
        // if (this.currentState == MachineState.FINISHED) {
        //     System.out.println("INFO: DivisibleNumbersMachine - Restarting machine.");
        // }

        this.divisibleNumbers.clear();
        this.currentNumberProcessed = 0;
        this.currentState = MachineState.RUNNING;
        // System.out.println("INFO: DivisibleNumbersMachine started. State: " + this.currentState);
    }

    /**
     * {@inheritDoc}
     * Checks if all numbers up to the threshold have been processed.
     * Each call to this method (while in the RUNNING state and not yet finished)
     * processes the next number to check if it's divisible by 4.
     *
     * @return {@code true} if all numbers up to the threshold have been processed,
     *         {@code false} otherwise.
     */
    @Override
    public boolean isFinished() {
        // System.out.println("DEBUG: DivisibleNumbersMachine - isFinished() called. State: " + this.currentState + ", Processed: " + this.currentNumberProcessed);
        if (this.currentState == MachineState.INITIALIZED) {
            // System.out.println("DEBUG: DivisibleNumbersMachine - isFinished: false (INITIALIZED).");
            return false; // Not started yet
        }
        if (this.currentState == MachineState.FINISHED) {
            // System.out.println("DEBUG: DivisibleNumbersMachine - isFinished: true (already FINISHED).");
            return true; // Already finished
        }

        // If running, perform a step of computation
        if (this.currentState == MachineState.RUNNING) {
            if (this.currentNumberProcessed < this.threshold) {
                this.currentNumberProcessed++; // Process numbers from 1 up to threshold
                if (this.currentNumberProcessed % 4 == 0) {
                    this.divisibleNumbers.add(this.currentNumberProcessed);
                    // System.out.println("DEBUG: DivisibleNumbersMachine - Found divisible number: " + this.currentNumberProcessed);
                }
                // System.out.println("DEBUG: DivisibleNumbersMachine - isFinished: false (RUNNING, processed " + this.currentNumberProcessed + "/" + this.threshold + ").");
                return false; // Still processing
            } else {
                // All numbers up to threshold have been processed
                // System.out.println("INFO: DivisibleNumbersMachine - Computation complete. All numbers up to threshold processed.");
                // The machine itself doesn't transition to FINISHED here.
                // The external caller calls finish() after this returns true.
                return true;
            }
        }
        return false; // Should not be reached if states are managed correctly
    }

    /**
     * {@inheritDoc}
     * Transitions the machine to the FINISHED state.
     * This method should be called after {@link #isFinished()} returns true.
     */
    @Override
    public void finish() {
        // System.out.println("INFO: DivisibleNumbersMachine - finish() called. Current state: " + this.currentState);
        if (this.currentState == MachineState.INITIALIZED) {
            // System.err.println("ERROR: DivisibleNumbersMachine - Cannot finish an unstarted machine.");
            throw new IllegalStateException("Machine has not been started yet.");
        }
        // It's valid to call finish() if already finished (idempotent) or if running and isFinished() would be true.
        // A stricter check might be: if (this.currentState == MachineState.RUNNING && this.currentNumberProcessed < this.threshold)
        // throw new IllegalStateException("Computation not yet complete, cannot finish.");

        this.currentState = MachineState.FINISHED;
        // System.out.println("INFO: DivisibleNumbersMachine finished. State: " + this.currentState + ". Results count: " + this.divisibleNumbers.size());
    }

    /**
     * {@inheritDoc}
     * Returns a list of all numbers found to be divisible by 4, up to the threshold.
     *
     * @return An unmodifiable list of integers.
     * @throws IllegalStateException if the machine is not in the FINISHED state.
     */
    @Override
    public List<Integer> getResult() {
        // System.out.println("INFO: DivisibleNumbersMachine - getResult() called. Current state: " + this.currentState);
        if (this.currentState != MachineState.FINISHED) {
            // System.err.println("ERROR: DivisibleNumbersMachine - Cannot get result, machine not in FINISHED state. Current state: " + this.currentState);
            throw new IllegalStateException("Machine is not in FINISHED state. Call start(), wait for isFinished() to be true, then call finish().");
        }
        // Return an unmodifiable list to protect internal state (Encapsulation)
        return Collections.unmodifiableList(this.divisibleNumbers);
    }
}