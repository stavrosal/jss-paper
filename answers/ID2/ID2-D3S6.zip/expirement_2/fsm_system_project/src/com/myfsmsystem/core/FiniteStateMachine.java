package com.myfsmsystem.core;

/**
 * Defines the core contract for all Finite State Machines (FSMs) in the system.
 * Each FSM manages a specific computational task through a consistent lifecycle.
 *
 * As per Bob-Complete's recommendation, this interface uses generics for
 * `getResult()` to provide better type safety for implementing machines.
 *
 * @param <T> The type of the result produced by the FSM's computation.
 */
public interface FiniteStateMachine<T> {

    /**
     * Initializes the machine and begins its computation.
     * This method should transition the machine to a 'RUNNING' state.
     * Any necessary setup, counter initializations, or resource allocations
     * should occur here.
     *
     * @throws IllegalStateException if the machine is not in a state
     *         where it can be started (e.g., already running or finished).
     */
    void start();

    /**
     * Checks if the machine's computation is complete.
     * This method is intended to be called repeatedly in a loop while the
     * machine is processing. For some FSMs, calling this method might also
     * advance the computation by a step.
     *
     * @return {@code true} if the computation is complete and the machine
     *         is ready for finalization, {@code false} otherwise.
     */
    boolean isFinished();

    /**
     * Performs cleanup operations and finalizes the computation results.
     * This method should be called after {@link #isFinished()} returns {@code true}.
     * It transitions the machine to a 'FINISHED' state.
     *
     * @throws IllegalStateException if the machine is not in a state
     *         where it can be finished (e.g., not yet started or computation not complete).
     */
    void finish();

    /**
     * Returns the result of the computation.
     * This method should only be called after {@link #finish()} has been successfully invoked
     * and the machine is in a 'FINISHED' state.
     *
     * @return The computation result of type T.
     * @throws IllegalStateException if the machine is not in the 'FINISHED' state
     *         or if results are not yet available.
     */
    T getResult();
}