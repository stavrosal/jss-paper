# Script to create FSM project directory structure
$ProjectName = "fsm_system_project"
$BaseDir = Join-Path -Path $PWD -ChildPath $ProjectName

# Create base project directory
New-Item -ItemType Directory -Path $BaseDir -ErrorAction SilentlyContinue | Out-Null
Write-Host "Created project directory: $BaseDir"

# Create src directory for source code
$SrcDir = Join-Path -Path $BaseDir -ChildPath "src"
New-Item -ItemType Directory -Path $SrcDir -ErrorAction SilentlyContinue | Out-Null

# Create package structure within src
$PackageBase = "com/myfsmsystem" # You can change 'myfsmsystem' to your preferred package name
$CorePackageDir = Join-Path -Path $SrcDir -ChildPath ($PackageBase + "/core")
$MachinesPackageDir = Join-Path -Path $SrcDir -ChildPath ($PackageBase + "/machines")
$AppPackageDir = Join-Path -Path $SrcDir -ChildPath $PackageBase # For the main App class

New-Item -ItemType Directory -Path $CorePackageDir -Force | Out-Null
New-Item -ItemType Directory -Path $MachinesPackageDir -Force | Out-Null
# AppPackageDir is implicitly created by $CorePackageDir and $MachinesPackageDir if $PackageBase has multiple parts

Write-Host "Created source package structure in: $SrcDir"
Write-Host "  - Core package: $($PackageBase.Replace('/', '.') + '.core')"
Write-Host "  - Machines package: $($PackageBase.Replace('/', '.') + '.machines')"

# Create bin directory for compiled class files
$BinDir = Join-Path -Path $BaseDir -ChildPath "bin"
New-Item -ItemType Directory -Path $BinDir -ErrorAction SilentlyContinue | Out-Null
Write-Host "Created bin directory for compiled classes: $BinDir"

Write-Host "Project structure for '$ProjectName' created successfully."
Write-Host "Next steps:"
Write-Host "1. Open the '$BaseDir' folder in VSCode."
Write-Host "2. Ensure you have the 'Extension Pack for Java' from Microsoft installed in VSCode."